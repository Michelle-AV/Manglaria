import SwiftUI

struct Sun: View {
    
    @State private var isShrinking = false

    var body: some View {
        ZStack {
            
//            Color.gray
            
            Circle()
                .foregroundStyle(.white.opacity(0.25))
                .frame(width: isShrinking ? 310 : 250)
                .animation(.easeInOut(duration: 1.5).repeatForever(autoreverses: true), value: isShrinking)
            Circle()
                .foregroundStyle(.white.opacity(0.5))
                .frame(width: isShrinking ? 220 : 180)
                .animation(.easeInOut(duration: 1.5).repeatForever(autoreverses: true), value: isShrinking)
            Circle()
                .foregroundStyle(.white)
                .frame(width: 150)
        }
        .onAppear{
            isShrinking.toggle()
        }
    }
}

#Preview {
    Sun()
}
