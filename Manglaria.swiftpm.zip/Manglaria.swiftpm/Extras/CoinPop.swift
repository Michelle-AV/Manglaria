import SwiftUI

struct CoinPop: View {
    
    @EnvironmentObject var appData: AppData
    @State private var coinMovement: Bool = false
    
    var body: some View {
        ZStack{
            Capsule()
                .foregroundStyle(.black.opacity(coinMovement ? 0.1 : 0.3))
                .frame(width:coinMovement ? 20 : 40, height: 4)
                .animation(.easeInOut(duration: 1.5).repeatForever(autoreverses: true), value: coinMovement)
                .offset(x: 1, y: 50)
            
            Image("Coin")
                .resizable()
                .scaledToFit()
                .frame(width: appData.UISW * 0.07)
                .offset(y: coinMovement ? -10 : 0)
                .animation(.easeInOut(duration: 1.5).repeatForever(autoreverses: true), value: coinMovement)
        }.onAppear{
            coinMovement.toggle()
        }
    }
}

#Preview {
    CoinPop()
        .environmentObject(AppData())
}
