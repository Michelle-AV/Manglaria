import SwiftUI

extension Color {
    
    // MARK: -Colors for Activity 3
    
    //Buttons
    public static let AO: Color = Color(UIColor(red: 0.04, green: 0.23, blue: 0.35, alpha: 1.00))
    public static let Blue: Color = Color(UIColor(red: 0.02, green: 0.31, blue: 0.46, alpha: 1.00))
    
    //Waters
    public static let AS: Color = Color(UIColor(red: 0.22, green: 0.23, blue: 0.13, alpha: 1.00)) //62% OP
    public static let AL: Color = Color(UIColor(red: 0.28, green: 0.51, blue: 0.76, alpha: 1.00))
    
    public static let Sky: Color = Color(UIColor(red: 0.58, green: 0.83, blue: 0.92, alpha: 1.00))

    public static let Rose: Color = Color(UIColor(red: 0.90, green: 0.10, blue: 0.36, alpha: 1.00))
    
    public static let Yellow: Color = Color(UIColor(red: 0.98, green: 0.83, blue: 0.28, alpha: 1.00))
    
    public static let GoldenL: Color = Color(UIColor(red: 0.89, green: 0.57, blue: 0.04, alpha: 1.00))
    
    public static let Sea: Color = Color(UIColor(red: 0.08, green: 0.67, blue: 0.85, alpha: 1.00))
    
}
