import SwiftUI

struct BuyAHeroView: View {
    
    @EnvironmentObject var appData: AppData
    
    @State private var heroSelected: String = "abbyInfo"

    var body: some View {
        ZStack{
            Image("buyCuadro")
                .resizable()
                .scaledToFit()
                .frame(width: appData.UISW * 0.96)
            
            Image(heroSelected)
                .resizable()
                .scaledToFit()
                .frame(width: appData.UISW * 0.38)
                .position(x: appData.UISW  * 0.735, y: appData.UISH * 0.51)
            
            Button{
                withAnimation (.spring(duration: 0.2)){
                    heroSelected = "abbyInfo"
                }
               
            } label: {
                Image("abbyFace")
                    .resizable()
                    .scaledToFit()
            }.frame(width: 100)
                .position(x: appData.UISW  * 0.14, y: appData.UISH * 0.33)
            
            Button{
                withAnimation (.spring(duration: 0.2)){
                    heroSelected = "lucasInfo"
                }
            } label: {
                Image("lucasFace")
                    .resizable()
                    .scaledToFit()
            }.frame(width: 100)
                .position(x: appData.UISW  * 0.273, y: appData.UISH * 0.33)
            
            Button{
                withAnimation (.spring(duration: 0.2)){
                    heroSelected = "SolisInfo"
                }
               
            } label: {
                Image("solisFac")
                    .resizable()
                    .scaledToFit()
            }.frame(width: 100)
                .position(x: appData.UISW  * 0.138, y: appData.UISH * 0.53)
            
            Button{
                withAnimation (.spring(duration: 0.2)){
                    heroSelected = "niloInfo"
                }
            } label: {
                Image("niloFace")
                    .resizable()
                    .scaledToFit()
            }.frame(width: 100)
                .position(x: appData.UISW  * 0.273, y: appData.UISH * 0.53)
            
        }.ignoresSafeArea()
    }
}

#Preview {
    BuyAHeroView()
        .environmentObject(AppData())
}
