import SwiftUI

struct Clouds: View {
    
    @EnvironmentObject var appData: AppData
    @State private var isMoving = false
    
    @State private var cloudsMovement: CGFloat = .zero
    @State private var cloudsMovement2: CGFloat = .zero

        var body: some View {
            ZStack {
                                    
                ZStack{
                    ForEach(cloudsData, id: \.name) { cloud in
                        Image(cloud.name)
                            .resizable()
                            .scaledToFit()
                            .frame(width: cloud.size)
                            .position(x: cloud.initialX * appData.UISW, y: cloud.initialY * appData.UISH)
                    }
                }.offset(x: cloudsMovement)
                    .onAppear {
                        Timer.scheduledTimer(withTimeInterval: 0.00002, repeats: true) { _ in
                            DispatchQueue.main.async {
                                cloudsMovement += 0.002
                                
                                if cloudsMovement > 1500 {
                                    cloudsMovement = -(appData.UISW * 1.2)
                                }
                            }
                        }
                    }
                
                ZStack{
                    ForEach(cloudsData, id: \.name) { cloud in
                        Image(cloud.name)
                            .resizable()
                            .scaledToFit()
                            .frame(width: cloud.size)
                            .position(x: cloud.initialX * appData.UISW, y: cloud.initialY * appData.UISH)
                    }
                }.position(x: appData.UISW * -0.7, y: appData.UISH * 0.5)
                    .offset(x: cloudsMovement2)
                    .onAppear {
                        Timer.scheduledTimer(withTimeInterval: 0.00002, repeats: true) { _ in
                            DispatchQueue.main.async {
                                cloudsMovement2 += 0.002

                                if cloudsMovement2 > 3000 {
                                    cloudsMovement2 = 0
                                }
                            }
                        }
                    }
            }
            .onAppear {
                isMoving.toggle()
            }
        }
}

struct Cloud {
    let name: String
    let size: CGFloat
    let initialX: CGFloat
    let initialY: CGFloat
}

let cloudsData: [Cloud] = [
    Cloud(name: "nube1", size: 130, initialX: 0.01, initialY: 0.22),
    Cloud(name: "nube3", size: 113, initialX: 0.42, initialY: 0.045),
    Cloud(name: "nube4", size: 165, initialX: 0.301, initialY: 0.385),
    Cloud(name: "nube4", size: 170, initialX: 0.616, initialY: 0.153),
    Cloud(name: "nube5", size: 166, initialX: 0.957, initialY: 0.335),
    Cloud(name: "nube6", size: 140, initialX: 1.005, initialY: 0.11),
    Cloud(name: "nube7", size: 100, initialX: 1, initialY: 0.534)
]

#Preview {
    Clouds()
        .environmentObject(AppData())
}

