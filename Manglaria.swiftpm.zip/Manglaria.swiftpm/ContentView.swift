import SwiftUI

struct ContentView: View {
    
    @EnvironmentObject var appData: AppData

    @State var hojaAnimation: CGFloat = .zero
    @State var tittleAnimation: CGFloat = .zero
    @State var nubes: CGFloat = .zero
    
    var body: some View {
        ZStack{
            Image("baseVaciaPortada")
                .resizable()
                .scaledToFill()
                .frame(width: appData.UISW)
            
            Image("ejemplo")
                .resizable()
                .scaledToFill()
                .frame(width: appData.UISW)
                .opacity(0.0)
            
            Rectangle()
                .foregroundStyle(Color.AL.opacity(0.62))
                .frame(width: appData.UISW, height: appData.UISH * 0.33)
                .position(x: appData.UISW * 0.5, y: appData.UISH * 0.85)
            
            Image("hoja1")
                .resizable()
                .scaledToFit()
                .frame(width: appData.UISW * 0.1)
                .position(x: appData.UISW * 0.21, y: appData.UISH * 0.25)
                .offset(x: hojaAnimation)
                .onAppear {
                    withAnimation(Animation.easeInOut(duration: 0.3).repeatForever(autoreverses: true)) {
                        hojaAnimation = 7
                    }
                }
            
            Image("hoja2")
                .resizable()
                .scaledToFit()
                .frame(width: appData.UISW * 0.05)
                .position(x: appData.UISW * 0.33, y: appData.UISH * 0.1)
                .offset(x: hojaAnimation)

            
            Image("hoja3")
                .resizable()
                .scaledToFit()
                .frame(width: appData.UISW * 0.07)
                .position(x: appData.UISW * 0.425, y: appData.UISH * 0.28)
                .offset(x: hojaAnimation)
            
            Image("hoja4")
                .resizable()
                .scaledToFit()
                .frame(width: appData.UISW * 0.07)
                .position(x: appData.UISW * 0.49, y: appData.UISH * 0.31)
                .offset(x: hojaAnimation)

            
            Image("hoja5")
                .resizable()
                .scaledToFit()
                .frame(width: appData.UISW * 0.07)
                .position(x: appData.UISW * 0.49, y: appData.UISH * 0.31)
                .offset(x: hojaAnimation)
            
            Image("hoja6")
                .resizable()
                .scaledToFit()
                .frame(width: appData.UISW * 0.07)
                .position(x: appData.UISW * 0.58, y: appData.UISH * 0.13)
                .offset(x: hojaAnimation)
            
            Image("hoja7")
                .resizable()
                .scaledToFit()
                .frame(width: appData.UISW * 0.09)
                .position(x: appData.UISW * 0.74, y: appData.UISH * 0.11)
                .offset(x: hojaAnimation)

            Image("hoja8")
                .resizable()
                .scaledToFit()
                .frame(width: appData.UISW * 0.04)
                .position(x: appData.UISW * 0.81, y: appData.UISH * 0.185)
                .offset(x: hojaAnimation)
            
            Image("hoja8")
                .resizable()
                .scaledToFit()
                .rotationEffect(Angle(degrees: 90))
                .frame(width: appData.UISW * 0.04)
                .position(x: appData.UISW * 0.54, y: appData.UISH * 0.27)
                .offset(x: hojaAnimation)
            
            
            Image("titulo")
                .resizable()
                .scaledToFit()
                .frame(width: appData.UISW * 0.61)
                .position(x: appData.UISW * 0.5, y: appData.UISH * 0.2)
                .offset(y: tittleAnimation)
                .onAppear {
                    withAnimation(Animation.easeInOut(duration: 1).repeatForever(autoreverses: true)) {
                        tittleAnimation = 8
                    }
                }
            
            Image("nubesPortada")
                .resizable()
                .scaledToFit()
                .position(x: appData.UISW * 0.5, y: appData.UISH * 0.18)
                .offset(y: -nubes)
                .onAppear {
                    withAnimation(Animation.easeInOut(duration: 1).repeatForever(autoreverses: true)) {
                        nubes = 5
                    }
                }
            
            Button{
                withAnimation (.easeInOut(duration: 0.5)){
                    appData.isMapView = true
                }
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                    withAnimation (.easeInOut(duration: 0.3)){
                        appData.isMapViewShowed = true
                    }
                }
            } label: {
                Image("startBtn")
                    .resizable()
                    .scaledToFit()
            }.frame(width: 270)
                .position(x: appData.UISW * 0.3, y: appData.UISH * 0.34)
                .offset(x: tittleAnimation)
            
            Button{
                withAnimation (.easeInOut(duration: 0.5)){
                    appData.isAbout = true
                }
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                    withAnimation (.easeInOut(duration: 0.3)){
                        appData.isAboutShowed = true
                    }
                }
            } label: {
                Image("aboutBtn")
                    .resizable()
                    .scaledToFit()
            }.frame(width: 270)
                .position(x: appData.UISW * 0.68, y: appData.UISH * 0.34)
                .offset(x: -tittleAnimation)
            
            Image("cajaPortada")
                .resizable()
                .scaledToFit()
                .frame(width: 150)
                .position(x: appData.UISW * 0.51, y: appData.UISH * 0.89)
                .offset(y: tittleAnimation)
            
            Image("manchaPortada")
                .resizable()
                .scaledToFit()
                .frame(width: 90)
                .position(x: appData.UISW * 0.63, y: appData.UISH * 0.93)
                .offset(x: -hojaAnimation)
            
            Image("heroePortada")
                .resizable()
                .scaledToFit()
                .frame(width: appData.UISW * 0.38)
                .position(x: appData.UISW * 0.26, y: appData.UISH * 0.7)
                .offset(y: -nubes)
            
            Image("villano2")
                .resizable()
                .scaledToFit()
                .frame(width: appData.UISW * 0.38)
                .position(x: appData.UISW * 0.77, y: appData.UISH * 0.64)
                .offset(y: nubes)
            
            Image("villano1")
                .resizable()
                .scaledToFit()
                .frame(width: appData.UISW * 0.38)
                .position(x: appData.UISW * 0.79, y: appData.UISH * 0.86)
                .offset(y: -nubes)
            
            if appData.isMapView {
                MapaView()
                    .offset(y: appData.isMapViewShowed ? 0 : appData.UISH * 1.5)
            } else if appData.isAbout {
                ZStack{
                    Rectangle()
                        .foregroundStyle(.black.opacity(appData.isAbout ? 0.5 : 0))
                        .frame(width: appData.UISW, height: appData.UISH)
                        .onTapGesture {
                            withAnimation (.easeInOut(duration: 0.5)){
                                appData.isAboutShowed = false
                            }
                            DispatchQueue.main.asyncAfter(deadline: .now() + 0.6) {
                                appData.isAbout = false
                            }
                        }
                    
                    ZStack{
                        Image("aboutInfo")
                            .resizable()
                            .scaledToFit()
    
                        Button {
                            withAnimation (.easeInOut(duration: 0.5)){
                                appData.isAboutShowed = false
                            }
                            DispatchQueue.main.asyncAfter(deadline: .now() + 0.6) {
                                appData.isAbout = false
                            }
                        } label: {
                            Image("xmark")
                                .resizable()
                                .scaledToFit()
                        }.frame(width: 60)
                            .position(x: appData.UISW * 0.83, y: appData.UISH * 0.21)
                        
                    }.frame(width: appData.UISW * 0.9)
                    .offset(y: appData.isAboutShowed ? 0 : appData.UISH * 1.5)
                }
                
            }
            
        }.ignoresSafeArea()
    }
}

#Preview {
    ContentView()
        .environmentObject(AppData())
}
