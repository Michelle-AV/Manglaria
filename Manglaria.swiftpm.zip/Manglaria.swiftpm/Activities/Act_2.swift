import SwiftUI

struct Act_2: View {
    
    @EnvironmentObject var appData: AppData
    
    @State var isFinished: Bool = false
    @State var isFinished2: Bool = false
    
    @State private var characterSelected: Bool = false
    @State var isBoySelected: Bool = false
    
    @State private var stepTutorial: Int = 0
    
    @State private var opacityCoin: Double = 0
    @State private var coinMovement: Bool = false
    @State var starting: Bool = true
    
    @State var offsetM1: CGFloat = .zero
    @State var offsetM2: CGFloat = .zero
    
    @State var offsetP1: CGFloat = .zero
    @State var isScreenP1: Bool = true
    @State var offsetP2: CGFloat = .zero
    @State var isScreenP2: Bool = true
    @State var offsetP3: CGFloat = .zero
    @State var isScreenP3: Bool = true
    @State var offsetP4: CGFloat = .zero
    @State var isScreenP4: Bool = true
    @State var offsetP5: CGFloat = .zero
    @State var isScreenP5: Bool = true
    @State var offsetP6: CGFloat = .zero
    @State var isScreenP6: Bool = true
    
    @State var isPopUp: Bool = true
    
    @State var isBananaClicked: Bool = false
    @State var isPopUpBanana: Bool = false
    @State var isCoinBanana: Bool = false
    @State var isEnabledBanana: Bool = true
    
    @State var isLataClicked: Bool = false
    @State var isPopUpLata: Bool = false
    @State var isCoinLata: Bool = false
    @State var isEnabledLata: Bool = true
    
    @State var isLata2Clicked: Bool = false
    @State var isPopUpLata2: Bool = false
    @State var isCoinLata2: Bool = false
    @State var isEnabledLata2: Bool = true
    
    @State var isCajaClicked: Bool = false
    @State var isPopUpCaja: Bool = false
    @State var isCoinCaja: Bool = false
    @State var isEnabledCaja: Bool = true
    
    @State var isCaja2Clicked: Bool = false
    @State var isPopUpCaja2: Bool = false
    @State var isCoinCaja2: Bool = false
    @State var isEnabledCaja2: Bool = true
    
    @State var isBotella1Clicked: Bool = false
    @State var isPopUpBotella: Bool = false
    @State var isCoinBotella: Bool = false
    @State var isEnabledBotella: Bool = true
    
    @State var isBotella2Clicked: Bool = false
    @State var isPopUpBotella2: Bool = false
    @State var isCoinBotella2: Bool = false
    @State var isEnabledBotella2: Bool = true
    
    @State var leftButtonPressed: Bool = false
    @State var rightButtonPressed: Bool = false
    
    @State var offsetHero: CGFloat = .zero
    @State var offsetFondo: CGFloat = .zero
    
    @State var timer: Timer?
    
    let timer2 = Timer.publish(every: 0.05, on: .main, in: .common).autoconnect()
    
    let leftLimit: CGFloat = -150
    let rightLimit: CGFloat = 450
    
    @State var isWalking: Bool = false
    @State var isFlipped: Bool = false
    @State var isTapping: Bool = false
    
    @State var offsetNubeT1: CGFloat = .zero
    @State var offsetNubeT2: CGFloat = .zero
    @State var offsetNubeT3: CGFloat = .zero
    
    @State var offsetBotella: CGFloat = .zero
    
    @State var offsetNubes: CGFloat = .zero
    
    var UISW: CGFloat = UIScreen.main.bounds.width
    var UISH: CGFloat = UIScreen.main.bounds.height
    
    var body: some View {
        ZStack{
            Image("base-niv1")
                .resizable()
                .scaledToFit()
                .frame(width: UISW * 1.7)
                .position(x: UISW * 0.84, y: UISH * 0.5)
                .offset(x: offsetFondo)
            
            Image("nube-tox")
                .resizable()
                .scaledToFit()
                .frame(width: 100)
                .position(x: UISW * 0.36, y: UISH * 0.12)
                .offset(y: offsetNubeT1)
                .offset(x: offsetFondo)
            
            Image("nube-tox")
                .resizable()
                .scaledToFit()
                .frame(width: 80)
                .position(x: UISW * 0.29, y: UISH * 0.18)
                .offset(y: offsetNubeT2)
                .opacity(/*@START_MENU_TOKEN@*/0.8/*@END_MENU_TOKEN@*/)
                .offset(x: offsetFondo)
            
            Image("nube-tox")
                .resizable()
                .scaledToFit()
                .frame(width: 60)
                .opacity(0.6)
                .position(x: UISW * 0.37, y: UISH * 0.2)
                .offset(y: offsetNubeT3)
                .offset(x: offsetFondo)
            
            Image("nubes-niv1")
                .resizable()
                .scaledToFit()
                .frame(width: UISW * 1.7)
                .position(x: UISW * 0.84, y: UISH * 0.195)
                .offset(y: offsetNubes)
                .offset(x: offsetFondo)
            
            Image("planta1")
                .resizable()
                .scaledToFit()
                .frame(width: 330)
                .position(x: UISW * 0.14, y: UISH * 0.55)
                .offset(x: offsetFondo)
                .offset(y: offsetM1)
            
            Image("planta2")
                .resizable()
                .scaledToFit()
                .frame(width: 400)
                .position(x: UISW * 0.8, y: UISH * 0.554)
                .offset(x: offsetFondo)
                .offset(y: offsetM2)
            
            Image("planta3")
                .resizable()
                .scaledToFit()
                .frame(width: 400)
                .position(x: UISW * 1.45, y: UISH * 0.554)
                .offset(x: offsetFondo)
                .offset(y: offsetM1)
            
            Image(isFinished2 ? "pez1" : "pez-nv1")
                .resizable()
                .scaledToFit()
                .frame(width: 50)
                .position(x: UISW * 0.047, y: UISH * 0.78)
                .offset(x: offsetP1)
                .opacity(isScreenP1 ? 1 : 0)
                .offset(x: offsetFondo)
            
            Image(isFinished2 ? "pez1" : "pez-nv1")                .resizable()
                .scaledToFit()
                .frame(width: 50)
                .position(x: UISW * 0.33, y: UISH * 0.852)
                .offset(x: offsetP2)
                .opacity(isScreenP2 ? 1 : 0)
                .offset(x: offsetFondo)
            
            Image(isFinished2 ? "pez1" : "pez-nv1")                .resizable()
                .scaledToFit()
                .frame(width: 50)
                .position(x: UISW * 0.58, y: UISH * 0.74)
                .offset(x: offsetP3)
                .opacity(isScreenP3 ? 1 : 0)
                .offset(x: offsetFondo)
            
            Image(isFinished2 ? "pez1" : "pez-nv1")                .resizable()
                .scaledToFit()
                .frame(width: 50)
                .position(x: UISW * 0.846, y: UISH * 0.903)
                .offset(x: offsetP4)
                .opacity(isScreenP4 ? 1 : 0)
                .offset(x: offsetFondo)
            
            Image(isFinished2 ? "pez1" : "pez-nv1")                .resizable()
                .scaledToFit()
                .frame(width: 50)
                .position(x: UISW * 1.33, y: UISH * 0.82)
                .offset(x: offsetP5)
                .opacity(isScreenP5 ? 1 : 0)
                .offset(x: offsetFondo)
            
            Image("platano")
                .resizable()
                .scaledToFit()
                .frame(width: 80)
                .position(x: UISW * 0.3, y: UISH * 0.87)
                .offset(x: offsetFondo)
                .opacity(isBananaClicked ? 0 : 1)
                .onTapGesture {
                    SoundManager.instance.playSound(sound: .gesture)
                    withAnimation (.spring(duration: 0.5)){
                        isPopUpBanana = true
                        isTapping = true
                        isPopUp = true
                    }
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                        withAnimation (.spring(duration: 0.5)){
                            isTapping = false
                        }
                    }
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.4) {
                        withAnimation (.spring(duration: 0.2)){
                            opacityCoin = 1
                        }
                    }
                }
            
            Image("lata2")
                .resizable()
                .scaledToFit()
                .frame(width: 90)
                .position(x: UISW * 0.9, y: UISH * 0.93)
                .offset(x: offsetFondo)
                .opacity(isLata2Clicked ? 0 : 1)
                .onTapGesture {
                    SoundManager.instance.playSound(sound: .gesture)
                    withAnimation (.spring(duration: 0.5)){
                        isPopUpLata = true
                        isTapping = true
                        isPopUp = true
                    }
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                        withAnimation (.spring(duration: 0.5)){
                            isTapping = false
                        }
                    }
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.4) {
                        withAnimation (.spring(duration: 0.2)){
                            opacityCoin = 1
                        }
                    }
                }
            
            Image("lata")
                .resizable()
                .scaledToFit()
                .frame(width: 70)
                .position(x: UISW * 1.4, y: UISH * 0.86)
                .offset(x: offsetFondo)
                .opacity(isLataClicked ? 0 : 1)
                .onTapGesture {
                    SoundManager.instance.playSound(sound: .gesture)
                    withAnimation (.spring(duration: 0.5)){
                        isPopUpLata2 = true
                        isTapping = true
                        isPopUp = true
                    }
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                        withAnimation (.spring(duration: 0.5)){
                            isTapping = false
                        }
                    }
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.4) {
                        withAnimation (.spring(duration: 0.2)){
                            opacityCoin = 1
                        }
                    }
                }

            Rectangle()
                .foregroundColor(isFinished ? Color(UIColor(red: 0.11, green: 0.60, blue: 0.71, alpha: 1.00)) : Color(UIColor(red: 0.17, green: 0.20, blue: 0.10, alpha: 1.00)))
                .frame(width: UISW, height: UISH * 0.4)
                .opacity(isFinished ? 0.6 : 0.52)
                .position(x: UISW * 0.5, y: UISH * 0.82)
                .allowsHitTesting(false)
            
            Image(isFinished ? "raiz-sana1" : "raices-planta1")
                .resizable()
                .scaledToFit()
                .frame(width: 250)
                .position(x: UISW * 0.141, y: UISH * 0.631)
                .offset(x: offsetFondo)
                .offset(y: offsetM1)
            
            Image(isFinished ? "raiz-sana2" : "raices-planta2")
                .resizable()
                .scaledToFit()
                .frame(width: 295)
                .position(x: UISW * 0.8, y: UISH * 0.645)
                .offset(x: offsetFondo)
                .offset(y: offsetM2)
            
            Image(isFinished ? "raiz-sana3" : "raices-planta3")
                .resizable()
                .scaledToFit()
                .frame(width: 295)
                .position(x: UISW * 1.45, y: UISH * 0.645)
                .offset(x: offsetFondo)
                .offset(y: offsetM1)
            
            Image("caja-en-agua")
                .resizable()
                .scaledToFit()
                .frame(width: 120)
                .position(x: UISW * 1.15, y: UISH * 0.631)
                .offset(x: offsetFondo)
                .offset(y: offsetBotella)
                .opacity(isCaja2Clicked ? 0 : 1)
                .onTapGesture {
                    SoundManager.instance.playSound(sound: .gesture)
                    withAnimation (.spring(duration: 0.5)){
                        isPopUpCaja2 = true
                        isTapping = true
                        isPopUp = true
                     }
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                        withAnimation (.spring(duration: 0.5)){
                            isTapping = false
                        }
                    }
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.4) {
                        withAnimation (.spring(duration: 0.2)){
                            opacityCoin = 1
                        }
                    }
                }
            
            Image("caja")
                .resizable()
                .scaledToFit()
                .frame(width: 65)
                .position(x: UISW * 0.14, y: UISH * 0.52)
                .offset(x: offsetFondo)
                .opacity(isCajaClicked ? 0 : 1)
                .onTapGesture {
                    SoundManager.instance.playSound(sound: .gesture)
                    withAnimation (.spring(duration: 0.5)){
                        isPopUpCaja = true
                        isTapping = true
                        isPopUp = true
                    }
                    coinMovement.toggle()
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                        withAnimation (.spring(duration: 0.5)){
                            isTapping = false
                        }
                    }
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.4) {
                        withAnimation (.spring(duration: 0.2)){
                            opacityCoin = 1
                        }
                    }
                }
                .offset(y: offsetM1)
            
            Image("hojas-botella1")
                .resizable()
                .scaledToFit()
                .frame(width: 70)
                .position(x: UISW * 0.14, y: UISH * 0.545)
                .offset(x: offsetFondo)
                .offset(y: offsetM1)
            
            Image("botella1")
                .resizable()
                .scaledToFit()
                .frame(width: 65)
                .position(x: UISW * 0.8, y: UISH * 0.52)
                .offset(x: offsetFondo)
                .opacity(isBotella1Clicked ? 0 : 1)
                .onTapGesture {
                    SoundManager.instance.playSound(sound: .gesture)
                    withAnimation (.spring(duration: 0.5)){
                        isPopUpBotella = true
                        isTapping = true
                        isPopUp = true
                    }
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                        withAnimation (.spring(duration: 0.5)){
                            isTapping = false
                        }
                    }
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.4) {
                        withAnimation (.spring(duration: 0.2)){
                            opacityCoin = 1
                        }
                    }
                }
                .offset(y: offsetM2)

            
            Image("hojas-botella1")
                .resizable()
                .scaledToFit()
                .frame(width: 70)
                .position(x: UISW * 0.8, y: UISH * 0.545)
                .offset(x: offsetFondo)
                .offset(y: offsetM2)
            
            Image("botella2")
                .resizable()
                .scaledToFit()
                .frame(width: 55)
                .position(x: UISW * 1.45, y: UISH * 0.52)
                .offset(x: offsetFondo)
                .opacity(isBotella2Clicked ? 0 : 1)
                .onTapGesture {
                    SoundManager.instance.playSound(sound: .gesture)
                    withAnimation (.spring(duration: 0.5)){
                        isPopUpBotella2 = true
                        isTapping = true
                        isPopUp = true
                    }
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                        withAnimation (.spring(duration: 0.5)){
                            isTapping = false
                        }
                    }
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.4) {
                        withAnimation (.spring(duration: 0.2)){
                            opacityCoin = 1
                        }
                    }
                }
                .offset(y: offsetM1)
            
            Image("hojas-botella2")
                .resizable()
                .scaledToFit()
                .frame(width: 70)
                .position(x: UISW * 1.45, y: UISH * 0.55)
                .offset(x: offsetFondo)
                .offset(y: offsetM1)
            
            if(isCajaClicked == true && isCaja2Clicked == true && isLataClicked == true && isLata2Clicked == true && isBotella1Clicked == true && isBotella2Clicked == true && isBananaClicked == true){
                Circle()
                    .foregroundColor(.white.opacity(0.000001))
                    .onAppear{
                        withAnimation (.easeInOut(duration: 0.5)){
                            isFinished = true
                        }
                        isFinished2 = true
                    }
            }
            
            PersonajeMainChill(isFlipped: $isFlipped, isTapping: $isTapping, isFinished: $isFinished, isBoySelected: $isBoySelected)
                .scaleEffect(0.7)
                .position(x: UISW * 0.4, y: UISH * 0.6)
                .offset(x: offsetHero)
            
//            Text("\(offsetP5)")
//                .font(.title)
//                .bold()
//                .foregroundColor(.white)
//                .padding(.bottom, 50)
//
//            Text("\(offsetFondo)")
//                .font(.title)
//                .bold()
//                .foregroundColor(.white)
            

            Image(leftButtonPressed == true ? "leftPressed" : "left")
                .resizable()
                .scaledToFit()
                .frame(width: 70)
                .position(x: UISW * 0.07, y: UISH * 0.69)
                .onLongPressGesture(minimumDuration: .infinity, pressing: { pressing in
                    if pressing {
                        isWalking = true
                        isFlipped = true
                        timer = Timer.scheduledTimer(withTimeInterval: 0.01, repeats: true) { _ in
                            DispatchQueue.main.async {
                                if offsetHero > leftLimit {
                                    if offsetFondo < 5 {
                                        offsetFondo += 1
                                    }
                                    offsetHero -= 1.1
                                } else {
                                    if offsetFondo < 5 {
                                        offsetFondo += 1
                                    }
                                }
                            }
                        }
                        leftButtonPressed = true
                    } else {
                        isWalking = false
                        isFlipped = true
                        timer?.invalidate()
                        timer = nil
                        leftButtonPressed = false
                    }
                }) {
                    isWalking = false
                    isFlipped = true
                    timer?.invalidate()
                    timer = nil
                    leftButtonPressed = false
                }
                .disabled(rightButtonPressed)
                .opacity(rightButtonPressed ? 0.6 : 1)

            
            Image(rightButtonPressed == true ? "rightPressed" :"rigth")
            .resizable()
            .scaledToFit()
            .frame(width: 70)
            .position(x: UISW * 0.93, y: UISH * 0.69)
            .onLongPressGesture(minimumDuration: .infinity, pressing: { pressing in
                if pressing {
                    isWalking = true
                    isFlipped = false
                    timer = Timer.scheduledTimer(withTimeInterval: 0.01, repeats: true) { _ in
                        DispatchQueue.main.async {
                            if offsetHero < rightLimit {
                                if offsetFondo > -810 {
                                    offsetFondo -= 1
                                }
                                offsetHero += 1.1
                            } else {
                                if offsetFondo > -810 {
                                    offsetFondo -= 1
                                }
                            }
                        }
                    }
                    rightButtonPressed = true
                } else {
                    isWalking = false
                    isFlipped = false
                    timer?.invalidate()
                    timer = nil
                    rightButtonPressed = false
                }
            }) {
                isWalking = false
                isFlipped = false
                timer?.invalidate()
                timer = nil
                rightButtonPressed = false
            }
            .disabled(leftButtonPressed)
            .opacity(leftButtonPressed ? 0.6 : 1)
            
            ZStack {
                Image("coinButton")
                    .resizable()
                    .scaledToFit()
                    
                Text(String(appData.coinsAmmount))
                    .font(.custom("RifficFree-Bold", size: 20))
                    .foregroundStyle(.white)
                    .offset(x: 23, y: 1)
            }.frame(width: 115)
                .position(x:appData.UISW * 0.923, y:appData.UISH * 0.075)
            
           
            ZStack {
                Image("bottleButton")
                    .resizable()
                    .scaledToFit()
                    
                Text(String(appData.bottlesAmmount))
                    .font(.custom("RifficFree-Bold", size: 20))
                    .foregroundStyle(.white)
                    .offset(x: 16, y: 8)
            }.frame(width: 103)
                .position(x:appData.UISW * 0.81, y:appData.UISH * 0.068)
            
            Button {
                withAnimation(.easeInOut(duration: 0.2)) {
                    appData.isTuto = true
                }
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                    withAnimation(.bouncy(duration: 0.2)){
                        stepTutorial = 1
                    }
                }
            } label: {
            Image("helpButton")
                .resizable()
                .scaledToFit()
                
            }.frame(width: 125)
                .position(x:appData.UISW * 0.69, y:appData.UISH * 0.077)
            
            Button {
                withAnimation (.easeInOut(duration: 0.5)){
                    appData.isLevel2Showed = false
                }
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.6) {
                    appData.isLevel2 = false
                }
            } label: {
                Image("backBtn")
                    .resizable()
                    .scaledToFit()
            }.frame(width: 70)
                .position(x: appData.UISW * 0.055, y: appData.UISH * 0.077)
            
            Rectangle()
                .foregroundColor(.black)
                .frame(width: UISW, height: UISH)
                .opacity(appData.isTuto ? 0 : isPopUp ? 0.6 : 0)
                .allowsHitTesting(true)
                .onAppear{
                    withAnimation(.easeInOut(duration: 0.2)) {
                        appData.isTuto = true
                        stepTutorial = 1
                    }
                }
             
            
            Image("pop-upBanana")
                .resizable()
                .scaledToFit()
                .frame(width: appData.UISW * 0.8)
                .offset(y: isPopUpBanana ? 0 : UISH * 1.5)
                .opacity(isPopUpBanana ? 1 : 0)
            
            Button{
                SoundManager.instance.playSound(sound: .coins)
                withAnimation (.easeInOut(duration: 0.5)){
                    appData.coinsAmmount += 40
                    isCoinBanana = true
                }
            } label: {
                Text("Get all!")
                    .font(.custom("RifficFree-Bold", size: 18))
                    .foregroundStyle(Color(UIColor(red: 0.89, green: 0.56, blue: 0.04, alpha: 1.00)))
                    .padding(.vertical, 3)
                    .padding(.horizontal, 38)
                    .background(Color(UIColor(red: 0.98, green: 0.83, blue: 0.28, alpha: 1.00)))
                    .cornerRadius(10)
            }.position(x: UISW * 0.795, y: UISH * 0.62)
                .disabled(isCoinBanana)
                .colorMultiply(!isCoinBanana ? .white.opacity(1) : .gray.opacity(0.5))
                .offset(y: isPopUpBanana ? 0 : UISH * 1.5)
                .opacity(isPopUpBanana ? 1 : 0)
            
            Image("PButton")
                .resizable()
                .scaledToFit()
                .frame(width: 180)
                .position(x: UISW * 0.505, y: UISH * 0.75)
                .onTapGesture {
                    withAnimation (.easeInOut(duration: 0.5)){
                        if(isCoinBanana == true){
                            SoundManager.instance.playSound(sound: .popup)
                            isBananaClicked = true
                            checkAllClean()
                            isPopUpBanana = false
                            isPopUp = false
                            SoundManager.instance.playSound(sound: .nivel)
                            opacityCoin = 0
                        } else {
                            isEnabledBanana = false
                            SoundManager.instance.playSound(sound: .coins)
                            withAnimation (.easeInOut(duration: 0.5)){
                                appData.coinsAmmount += 40
                                isCoinBanana = true
                            }
                            DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                                SoundManager.instance.playSound(sound: .popup)
                                withAnimation (.easeInOut(duration: 0.2)){
                                    opacityCoin = 0
                                }
                                withAnimation (.easeInOut(duration: 0.5)){
                                    isBananaClicked = true
                                    checkAllClean()
                                    isPopUpBanana = false
                                    isPopUp = false
                                    SoundManager.instance.playSound(sound: .nivel)
                                }
                            }
                        }
                    }
                }
                .offset(y: isPopUpBanana ? 0 : UISH * 1.5)
                .opacity(isPopUpBanana ? 1 : 0)
                .disabled(!isEnabledBanana)
            
            Image("pop-upCarton")
                .resizable()
                .scaledToFit()
                .frame(width: appData.UISW * 0.8)
                .offset(y: isPopUpCaja ? 0 : UISH * 1.5)
                .opacity(isPopUpCaja ? 1 : 0)

            Button{
                SoundManager.instance.playSound(sound: .coins)
                withAnimation (.easeInOut(duration: 0.5)){
                    appData.coinsAmmount += 40
                    isCoinCaja = true
                }
            } label: {
                Text("Get all!")
                    .font(.custom("RifficFree-Bold", size: 18))
                    .foregroundStyle(Color(UIColor(red: 0.89, green: 0.56, blue: 0.04, alpha: 1.00)))
                    .padding(.vertical, 3)
                    .padding(.horizontal, 38)
                    .background(Color(UIColor(red: 0.98, green: 0.83, blue: 0.28, alpha: 1.00)))
                    .cornerRadius(10)
            }.position(x: UISW * 0.7953, y: UISH * 0.62)
                .disabled(isCoinCaja)
                .colorMultiply(!isCoinCaja ? .white.opacity(1) : .gray.opacity(0.5))
                .offset(y: isPopUpCaja ? 0 : UISH * 1.5)
                .opacity(isPopUpCaja ? 1 : 0)
            
            Image("PButton")
                .resizable()
                .scaledToFit()
                .frame(width: 180)
                .position(x: UISW * 0.505, y: UISH * 0.75)
                .onTapGesture {
                    withAnimation (.easeInOut(duration: 0.5)){
                        if(isCoinCaja == true){
                            SoundManager.instance.playSound(sound: .popup)
                            isCajaClicked = true
                            checkAllClean()
                            isPopUpCaja = false
                            isPopUp = false
                            SoundManager.instance.playSound(sound: .nivel)
                            opacityCoin = 0
                        } else {
                            isEnabledCaja = false
                            SoundManager.instance.playSound(sound: .coins)
                            withAnimation (.easeInOut(duration: 0.5)){
                                appData.coinsAmmount += 40
                                isCoinCaja = true
                            }
                            DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                                SoundManager.instance.playSound(sound: .popup)
                                withAnimation (.easeInOut(duration: 0.2)){
                                    opacityCoin = 0
                                }
                                withAnimation (.easeInOut(duration: 0.5)){
                                    isCajaClicked = true
                                    checkAllClean()
                                    isPopUpCaja = false
                                    isPopUp = false
                                    SoundManager.instance.playSound(sound: .nivel)
                                }
                            }
                        }
                    }
                }
                .offset(y: isPopUpCaja ? 0 : UISH * 1.5)
                .opacity(isPopUpCaja ? 1 : 0)
                .disabled(!isEnabledCaja)
            
            Image("pop-upCarton")
                .resizable()
                .scaledToFit()
                .frame(width: appData.UISW * 0.8)
                .offset(y: isPopUpCaja2 ? 0 : UISH * 1.5)
                .opacity(isPopUpCaja2 ? 1 : 0)
            
            Button{
                SoundManager.instance.playSound(sound: .coins)
                withAnimation (.easeInOut(duration: 0.5)){
                    appData.coinsAmmount += 40
                    isCoinCaja2 = true
                }
            } label: {
                Text("Get all!")
                    .font(.custom("RifficFree-Bold", size: 18))
                    .foregroundStyle(Color(UIColor(red: 0.89, green: 0.56, blue: 0.04, alpha: 1.00)))
                    .padding(.vertical, 3)
                    .padding(.horizontal, 38)
                    .background(Color(UIColor(red: 0.98, green: 0.83, blue: 0.28, alpha: 1.00)))
                    .cornerRadius(10)
            }.position(x: UISW * 0.7953, y: UISH * 0.62)
                .disabled(isCoinCaja2)
                .colorMultiply(!isCoinCaja2 ? .white.opacity(1) : .gray.opacity(0.5))
                .offset(y: isPopUpCaja2 ? 0 : UISH * 1.5)
                .opacity(isPopUpCaja2 ? 1 : 0)
            
            Image("PButton")
                .resizable()
                .scaledToFit()
                .frame(width: 180)
                .position(x: UISW * 0.505, y: UISH * 0.75)
                .onTapGesture {
                    withAnimation (.easeInOut(duration: 0.5)){
                        if(isCoinCaja2 == true){
                            withAnimation (.easeInOut(duration: 0.2)){
                                opacityCoin = 0
                            }
                            SoundManager.instance.playSound(sound: .popup)
                            isCaja2Clicked = true
                            checkAllClean()
                            isPopUpCaja2 = false
                            isPopUp = false
                            SoundManager.instance.playSound(sound: .nivel)
                        } else {
                            isEnabledCaja2 = false
                            SoundManager.instance.playSound(sound: .coins)
                            withAnimation (.easeInOut(duration: 0.5)){
                                appData.coinsAmmount += 40
                                isCoinCaja2 = true
                            }
                            DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                                SoundManager.instance.playSound(sound: .popup)
                                withAnimation (.easeInOut(duration: 0.2)){
                                    opacityCoin = 0
                                }
                                withAnimation (.easeInOut(duration: 0.5)){
                                    isCaja2Clicked = true
                                    checkAllClean()
                                    isPopUpCaja2 = false
                                    isPopUp = false
                                    SoundManager.instance.playSound(sound: .nivel)
                                }
                            }
                        }
                    }
                }
                .offset(y: isPopUpCaja2 ? 0 : UISH * 1.5)
                .opacity(isPopUpCaja2 ? 1 : 0)
                .disabled(!isEnabledCaja2)
            
            Image("pop-upBotella")
                .resizable()
                .scaledToFit()
                .frame(width: appData.UISW * 0.8)
                .offset(y: isPopUpBotella ? 0 : UISH * 1.5)
                .opacity(isPopUpBotella ? 1 : 0)
 
            Button{
                SoundManager.instance.playSound(sound: .coins)
                withAnimation (.easeInOut(duration: 0.5)){
                    appData.coinsAmmount += 40
                    isCoinBotella = true
                }
            } label: {
                Text("Get all!")
                    .font(.custom("RifficFree-Bold", size: 18))
                    .foregroundStyle(Color(UIColor(red: 0.89, green: 0.56, blue: 0.04, alpha: 1.00)))
                    .padding(.vertical, 3)
                    .padding(.horizontal, 38)
                    .background(Color(UIColor(red: 0.98, green: 0.83, blue: 0.28, alpha: 1.00)))
                    .cornerRadius(10)
            }.position(x: UISW * 0.7953, y: UISH * 0.62)
                .opacity(opacityCoin)
                .disabled(isCoinBotella)
                .colorMultiply(!isCoinBotella ? .white.opacity(1) : .gray.opacity(0.5))
                .offset(y: isPopUpBotella ? 0 : UISH * 1.5)
                .opacity(isPopUpBotella ? 1 : 0)
            
            Image("PButton")
                .resizable()
                .scaledToFit()
                .frame(width: 180)
                .position(x: UISW * 0.505, y: UISH * 0.75)
                .onTapGesture {
                    withAnimation (.easeInOut(duration: 0.5)){
                        if(isCoinBotella == true){
                            SoundManager.instance.playSound(sound: .popup)
                            isBotella1Clicked = true
                            checkAllClean()
                            isPopUpBotella = false
                            isPopUp = false
                            SoundManager.instance.playSound(sound: .nivel)
                            withAnimation (.easeInOut(duration: 0.2)){
                                opacityCoin = 0
                            }
                        } else {
                            isEnabledBotella = false
                            SoundManager.instance.playSound(sound: .coins)
                            withAnimation (.easeInOut(duration: 0.5)){
                                appData.coinsAmmount += 40
                                isCoinBotella = true
                            }
                            DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                                SoundManager.instance.playSound(sound: .popup)
                                withAnimation (.easeInOut(duration: 0.2)){
                                    opacityCoin = 0
                                }
                                withAnimation (.easeInOut(duration: 0.5)){
                                    isBotella1Clicked = true
                                    checkAllClean()
                                    isPopUpBotella = false
                                    isPopUp = false
                                    SoundManager.instance.playSound(sound: .nivel)
                                }
                            }
                        }
                    }
                }
                .offset(y: isPopUpBotella ? 0 : UISH * 1.5)
                .opacity(isPopUpBotella ? 1 : 0)
                .disabled(!isEnabledBotella)
            
            Image("pop-upBotellaVerde")
                .resizable()
                .scaledToFit()
                .frame(width: appData.UISW * 0.8)
                .offset(y: isPopUpBotella2 ? 0 : UISH * 1.5)
                .opacity(isPopUpBotella2 ? 1 : 0)

            Button{
                SoundManager.instance.playSound(sound: .coins)
                withAnimation (.easeInOut(duration: 0.5)){
                    appData.coinsAmmount += 40
                    isCoinBotella2 = true
                }
            } label: {
                Text("Get all!")
                    .font(.custom("RifficFree-Bold", size: 18))
                    .foregroundStyle(Color(UIColor(red: 0.89, green: 0.56, blue: 0.04, alpha: 1.00)))
                    .padding(.vertical, 3)
                    .padding(.horizontal, 38)
                    .background(Color(UIColor(red: 0.98, green: 0.83, blue: 0.28, alpha: 1.00)))
                    .cornerRadius(10)
            }.position(x: UISW * 0.7953, y: UISH * 0.62)
                .disabled(isCoinBotella2)
                .colorMultiply(!isCoinBotella2 ? .white.opacity(1) : .gray.opacity(0.5))
                .offset(y: isPopUpBotella2 ? 0 : UISH * 1.5)
                .opacity(isPopUpBotella2 ? 1 : 0)
            
            Image("PButton")
                .resizable()
                .scaledToFit()
                .frame(width: 180)
                .position(x: UISW * 0.505, y: UISH * 0.75)
                .onTapGesture {
                    withAnimation (.easeInOut(duration: 0.5)){
                        if(isCoinBotella2 == true){
                            SoundManager.instance.playSound(sound: .popup)
                            isBotella2Clicked = true
                            checkAllClean()
                            isPopUpBotella2 = false
                            isPopUp = false
                            SoundManager.instance.playSound(sound: .nivel)
                            withAnimation (.easeInOut(duration: 0.2)){
                                opacityCoin = 0
                            }                        } else {
                            isEnabledBotella2 = false
                            SoundManager.instance.playSound(sound: .coins)
                            withAnimation (.easeInOut(duration: 0.5)){
                                appData.coinsAmmount += 40
                                isCoinBotella2 = true
                            }
                            DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                                SoundManager.instance.playSound(sound: .popup)
                                withAnimation (.easeInOut(duration: 0.2)){
                                    opacityCoin = 0
                                }
                                withAnimation (.easeInOut(duration: 0.5)){
                                    isBotella2Clicked = true
                                    checkAllClean()
                                    isPopUpBotella2 = false
                                    isPopUp = false
                                    SoundManager.instance.playSound(sound: .nivel)
                                }
                            }
                        }
                    }
                }
                .offset(y: isPopUpBotella2 ? 0 : UISH * 1.5)
                .opacity(isPopUpBotella2 ? 1 : 0)
                .disabled(!isEnabledBotella2)
            
            Image("pop-upLataAzul")
                .resizable()
                .scaledToFit()
                .frame(width: appData.UISW * 0.8)
                .offset(y: isPopUpLata ? 0 : UISH * 1.5)
                .opacity(isPopUpLata ? 1 : 0)

            Button{
                SoundManager.instance.playSound(sound: .coins)
                withAnimation (.easeInOut(duration: 0.5)){
                    appData.coinsAmmount += 40
                    isCoinLata = true
                }
            } label: {
                Text("Get all!")
                    .font(.custom("RifficFree-Bold", size: 18))
                    .foregroundStyle(Color(UIColor(red: 0.89, green: 0.56, blue: 0.04, alpha: 1.00)))
                    .padding(.vertical, 3)
                    .padding(.horizontal, 38)
                    .background(Color(UIColor(red: 0.98, green: 0.83, blue: 0.28, alpha: 1.00)))
                    .cornerRadius(10)
            }
            .position(x: UISW * 0.7953, y: UISH * 0.62)
                .disabled(isCoinLata)
                .colorMultiply(!isCoinLata ? .white.opacity(1) : .gray.opacity(0.5))
                .offset(y: isPopUpLata ? 0 : UISH * 1.5)
                .opacity(isPopUpLata ? 1 : 0)
            
            Image("PButton")
                .resizable()
                .scaledToFit()
                .frame(width: 180)
                .position(x: UISW * 0.505, y: UISH * 0.75)
                .onTapGesture {
                    withAnimation (.easeInOut(duration: 0.5)){
                        if(isCoinLata == true){
                            withAnimation (.easeInOut(duration: 0.2)){
                                opacityCoin = 0
                            }
                            SoundManager.instance.playSound(sound: .popup)
                            isLata2Clicked = true
                            checkAllClean()
                            isPopUpLata = false
                            isPopUp = false
                            SoundManager.instance.playSound(sound: .nivel)
                        } else {
                            isEnabledLata = false
                            SoundManager.instance.playSound(sound: .coins)
                            withAnimation (.easeInOut(duration: 0.5)){
                                appData.coinsAmmount += 40
                                isCoinLata = true
                            }
                            DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                                SoundManager.instance.playSound(sound: .popup)
                                withAnimation (.easeInOut(duration: 0.2)){
                                    opacityCoin = 0
                                }
                                withAnimation (.easeInOut(duration: 0.5)){
                                    isLata2Clicked = true
                                    checkAllClean()
                                    isPopUpLata = false
                                    isPopUp = false
                                    SoundManager.instance.playSound(sound: .nivel)
                                }
                            }
                        }
                    }
                }
                .offset(y: isPopUpLata ? 0 : UISH * 1.5)
                .opacity(isPopUpLata ? 1 : 0)
                .disabled(!isEnabledLata)
            
            Image("pop-upLataRoja")
                .resizable()
                .scaledToFit()
                .frame(width: appData.UISW * 0.8)
                .offset(y: isPopUpLata2 ? 0 : UISH * 1.5)
                .opacity(isPopUpLata2 ? 1 : 0)

            Button{
                SoundManager.instance.playSound(sound: .coins)
                withAnimation (.easeInOut(duration: 0.5)){
                    appData.coinsAmmount += 40
                    isCoinLata2 = true
                }
            } label: {
                Text("Get all!")
                    .font(.custom("RifficFree-Bold", size: 18))
                    .foregroundStyle(Color(UIColor(red: 0.89, green: 0.56, blue: 0.04, alpha: 1.00)))
                    .padding(.vertical, 3)
                    .padding(.horizontal, 38)
                    .background(Color(UIColor(red: 0.98, green: 0.83, blue: 0.28, alpha: 1.00)))
                    .cornerRadius(10)
            }
            .position(x: UISW * 0.7953, y: UISH * 0.62)
                .disabled(isCoinLata2)
                .colorMultiply(!isCoinLata2 ? .white.opacity(1) : .gray.opacity(0.5))
                .offset(y: isPopUpLata2 ? 0 : UISH * 1.5)
                .opacity(isPopUpLata2 ? 1 : 0)
            
            Image("PButton")
                .resizable()
                .scaledToFit()
                .frame(width: 180)
                .position(x: UISW * 0.505, y: UISH * 0.75)
                .onTapGesture {
                    withAnimation (.easeInOut(duration: 0.5)){
                        if(isCoinLata2 == true){
                            withAnimation (.easeInOut(duration: 0.2)){
                                opacityCoin = 0
                            }
                            SoundManager.instance.playSound(sound: .popup)
                            isLataClicked = true
                            checkAllClean()
                            isPopUpLata2 = false
                            isPopUp = false
                            SoundManager.instance.playSound(sound: .nivel)
                        } else {
                            isEnabledLata2 = false
                            SoundManager.instance.playSound(sound: .coins)
                            withAnimation (.easeInOut(duration: 0.5)){
                                appData.coinsAmmount += 40
                                isCoinLata2 = true
                            }
                            DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                                SoundManager.instance.playSound(sound: .popup)
                                withAnimation (.easeInOut(duration: 0.2)){
                                    opacityCoin = 0
                                }
                                withAnimation (.easeInOut(duration: 0.5)){
                                    isLataClicked = true
                                    checkAllClean()
                                    isPopUpLata2 = false
                                    isPopUp = false
                                    SoundManager.instance.playSound(sound: .nivel)
                                }
                            }
                        }
                    }
                }
                .offset(y: isPopUpLata2 ? 0 : UISH * 1.5)
                .opacity(isPopUpLata2 ? 1 : 0)
                .disabled(!isEnabledLata2)
            
            CoinPop()
                .position(x: appData.UISW * 0.798, y: appData.UISH * 0.46)
                .opacity(opacityCoin)
            
            if appData.isTuto {
                Rectangle()
                    .foregroundStyle(.black.opacity(appData.isTuto ? 0.6 : 0))
                    .frame(width: appData.UISW, height: appData.UISH)
                
                ZStack{
                    Image("step1act2")
                        .resizable()
                        .scaledToFit()
                        .frame(width: appData.UISW * 0.8)
                    
                    Image("face1")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 110)
                        .position(x: appData.UISW * 0.81, y: appData.UISH * 0.31)
                    
                    Button {
                        withAnimation(.bouncy(duration: 0.5)){
                            if stepTutorial == 1 {
                                stepTutorial = 2
                            }
                        }
                    } label: {
                        Image("nextBtn")
                            .resizable()
                            .scaledToFit()
                    }.frame(width: appData.UISW * 0.12)
                        .position(x: appData.UISW * 0.5, y: appData.UISH * 0.69)
                    
                }.offset(y: stepTutorial == 2 || stepTutorial == 3 ? appData.UISH * -1.5 : (stepTutorial == 1 ? 0 : appData.UISH * 1.5))
                .zIndex(1.1)
                
                ZStack{
                    Image("step2act2")
                        .resizable()
                        .scaledToFit()
                        .frame(width: appData.UISW * 0.8)

                    Image("face2")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 100)
                        .position(x: appData.UISW * 0.81, y: appData.UISH * 0.31)
                    
                    Button {
                        withAnimation(.bouncy(duration: 0.5)){
                            if stepTutorial == 2 {
                                stepTutorial = 3
                            }
                        }
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                            withAnimation(.easeInOut(duration: 0.2)){
                                appData.isTuto = false
                            }
                        }
                    } label: {
                        Image("okayBtn")
                            .resizable()
                            .scaledToFit()
                    }.frame(width: appData.UISW * 0.12)
                        .position(x: appData.UISW * 0.5, y: appData.UISH * 0.69)
                    
                }.opacity(stepTutorial == 3 ? 0 : 1)
                .offset(y: stepTutorial == 3 ? appData.UISH * -1.5 : (stepTutorial == 2 ? 0 : appData.UISH * 1.5))
                .zIndex(1.1)
            }
            Image("pop-up-n1")
                .resizable()
                .scaledToFit()
                .frame(width: UISW * 0.6)
                .offset(y: starting ? 0 : UISH * 2)
                .offset(y: offsetNubes)
            
            ZStack{
                Image("selectedHero")
                    .resizable()
                    .scaledToFit()
                    .frame(width: UISW * 0.9)
                
                Button{
                    withAnimation(.easeInOut(duration: 0.5)){
                        characterSelected = true
                    }
                    withAnimation (.easeInOut(duration: 0.6)){
                        starting = false
                        isPopUp = false
                    }
                } label: {
                    Image("selectHBtn")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 200)
                        .position(x: UISW * 0.5, y: UISH * 0.9)
                }
                
                Image("lunaSombra")
                    .resizable()
                    .scaledToFit()
                    .frame(width: isBoySelected ? UISW * 0.3 : UISW * 0.32)
                    .position(x: UISW * 0.32, y: UISH * 0.54)
                
                Image("luna")
                    .resizable()
                    .scaledToFit()
                    .frame(width: isBoySelected ? UISW * 0.3 : UISW * 0.32)
                    .position(x: isBoySelected ? UISW * 0.32 : UISW * 0.3, y: isBoySelected ? UISH * 0.54 : UISH * 0.52)
                    .onTapGesture {
                        withAnimation(.easeInOut(duration: 0.2)) {
                            isBoySelected = false
                        }
                    }
                
                Image("kaelSombra")
                    .resizable()
                    .scaledToFit()
                    .frame(width: !isBoySelected ? UISW * 0.3 : UISW * 0.32)
                    .position(x: UISW * 0.72, y: UISH * 0.54)
                
                Image("kael")
                    .resizable()
                    .scaledToFit()
                    .frame(width: !isBoySelected ? UISW * 0.3 : UISW * 0.32)
                    .position(x: isBoySelected ? UISW * 0.7 : UISW * 0.72, y: isBoySelected ? UISH * 0.52 : UISH * 0.54)
                    .onTapGesture {
                        withAnimation(.easeInOut(duration: 0.2)) {
                            isBoySelected = true
                        }
                    }
            }.opacity(characterSelected ? 0 : appData.isTuto ? 0 : 1)
                .zIndex(1.0)
            
            Rectangle()
                .foregroundStyle(.black.opacity(appData.isFinal ? 0.6 : 0))
                .frame(width: appData.UISW, height: appData.UISH)
                .zIndex(1.1)
            
            if appData.isFinal {
                ZStack {
                    Image("mensajeFinalAct2")
                        .resizable()
                        .scaledToFit()
                    
                    Button{
                        withAnimation (.easeInOut(duration: 0.5)){
                            appData.isFinal = false
                            appData.bottlesAmmount += 2
                            appData.isLevel2Complete = true
                        }
                    } label: {
                        Image("letsBtn")
                            .resizable()
                            .scaledToFit()
                        
                    }.frame(width: 130)
                        .position(x: appData.UISW * 0.3, y: appData.UISH * 0.86)
                    
                }.frame(width: appData.UISW * 0.6)
                .zIndex(1.1)
            }

        }.ignoresSafeArea()
            .onReceive(timer2) { _ in
                if(offsetP1 > 2000){
                    isScreenP1 = false
                    offsetP1 = -UISW * 0.1
                } else {
                    offsetP1 += 3
                    isScreenP1 = true
                }
                if(offsetP2 > 1600){
                    isScreenP2 = false
                    offsetP2 = -UISW * 0.4
                } else {
                    offsetP2 += 2
                    isScreenP2 = true
                }
                if(offsetP3 > 1500){
                    isScreenP3 = false
                    offsetP3 = -UISW * 0.7
                } else {
                    offsetP3 += 2.5
                    isScreenP3 = true
                }
                if(offsetP4 > 1100){
                    isScreenP4 = false
                    offsetP4 = -UISW * 1.1
                } else {
                    offsetP4 += 3
                    isScreenP4 = true
                }
                if(offsetP5 > 500){
                    isScreenP5 = false
                    offsetP5 = -UISW * 1.35
                } else {
                    offsetP5 += 2
                    isScreenP5 = true
                }
            }
            .onAppear{
//                DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
//                    withAnimation (.easeInOut(duration: 0.8)){
//                        starting = false
//                        isPopUp = false
//                    }
//                }
                withAnimation(Animation.easeInOut(duration: 1.5).repeatForever()) {
                    offsetNubeT1 += 18
                    if offsetNubeT1 > 9 {
                        offsetNubeT1 = -9
                    }
                    offsetBotella += 14
                    if offsetBotella > 7{
                        offsetBotella = -7
                    }
                }
                withAnimation(Animation.easeInOut(duration: 1.8).repeatForever()) {
                    offsetNubes += 20
                    if offsetNubes > 10 {
                        offsetNubes = -10
                    }
                    offsetM1 += 4
                    if offsetBotella > 2{
                        offsetBotella = -2
                    }
                    offsetM2 -= 4
                    if offsetBotella < 2{
                        offsetBotella = 2
                    }
                }
                withAnimation(Animation.easeInOut(duration: 1.2).repeatForever()) {
                    offsetNubeT2 += 16
                    if offsetNubeT2 > 8 {
                        offsetNubeT2 = -8
                    }
                }
                withAnimation(Animation.easeInOut(duration: 1.3).repeatForever()) {
                    offsetNubeT3 += 12
                    if offsetNubeT3 > 6 {
                        offsetNubeT3 = -6
                    }
                }
            }
    }
    
    func checkAllClean () {
        if isCajaClicked && isCaja2Clicked && isLataClicked && isLata2Clicked &&
           isBotella1Clicked && isBotella2Clicked && isBananaClicked {
            
            DispatchQueue.main.async {
                withAnimation (.easeInOut(duration: 0.5)) {
                    isFinished = true
                    appData.isFinal = true
                }
                isFinished2 = true
            }
        }
    }
}

struct Nivel1_Previews: PreviewProvider {
    static var previews: some View {
        let count = State(initialValue: 0)
        let coins = State(initialValue: 0)
        let level1 = State(initialValue: false)
        
        return Act_2()
        .environmentObject(AppData())
    }
}
