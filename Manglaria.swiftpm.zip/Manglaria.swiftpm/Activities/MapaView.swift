import SwiftUI

struct MapaView: View {
    
    @EnvironmentObject var appData: AppData
    
    @State private var stepTutorial: Int = 0
    @State var isFinished: Bool = false
    @State var isFinished2: Bool = false
    
    var UISW: CGFloat = UIScreen.main.bounds.width
    var UISH: CGFloat = UIScreen.main.bounds.height
    
    @State var offsetBote2: CGFloat = .zero
    @State var offsetBotella: CGFloat = .zero
    @State var offsetLiquido: CGFloat = .zero
    
    @State var offsetHumo1: CGFloat = .zero
    @State var offsetLevels: CGFloat = .zero

    @State var isTapped1: Bool = false
    @State var isTapped2: Bool = false
    @State var isTapped3: Bool = false
    @State var isTapped4: Bool = false
    @State var isTapped5: Bool = false
                            
    @State var isPopUp: Bool = false
    
    var body: some View {
        ZStack{
            Color.Sea
            
            VStack (spacing: -10){
                Text("Welcome to")
                    .font(.custom("RifficFree-Bold", size: 40))
                    .foregroundStyle(.white)
                    .offset(x: -10)
                
                Text("Manglaria")
                    .font(.custom("RifficFree-Bold", size: 110))
                    .foregroundStyle(.white)
                    .offset(x: UISW * 0.12)

            }.position(x: UISW * 0.135, y: UISH * 0.15)
            
            ScrollView(.horizontal, showsIndicators: false){
                ScrollViewReader{ proxy in
                    ZStack {
                        Image("base1")
                            .resizable()
                            .frame(width: UISW * 1.5,height: UISH * 0.89)
                            .position(x: UISW * 0.75, y: UISH * 0.57)
                        
                        Image("cangrejo-nv1")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 50)
                            .scaleEffect(x: -1, y: 1, anchor: .center)
                            .position(x: UISW * 0.48, y: UISH * 0.58)
                        
                        Image("cangrejo-nv1")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 50)
                            .position(x: UISW * 0.55, y: UISH * 0.69)
                        
                        Image("cocodrilo-nv1")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 160)
                            .position(x: UISW * 0.798, y: UISH * 0.505)
                        
                        Image("garza-nv1")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 100)
                            .position(x: UISW * 0.764, y: UISH * 0.537)
                        
                        Image("bote2")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 120)
                            .position(x: UISW * 1.085, y: UISH * 0.91)
                            .offset(y: offsetBote2)
                        
                        Image("gotas-abajo")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 70)
                            .position(x: UISW * 0.993, y: UISH * 0.372)
                            .offset(x: offsetLiquido)
                        
                        Image("liquido")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 70)
                            .position(x: UISW * 1.01, y: UISH * 0.33)
                        
                        Image("gotas-frente")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 70)
                            .position(x: UISW * 0.99, y: UISH * 0.373)
                            .offset(x: offsetLiquido)
                        
                        Image("bote1")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 100)
                            .position(x: UISW * 1.06, y: UISH * 0.29)
                        
                        Image("botella")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 80)
                            .position(x: UISW * 1.1, y: UISH * 0.52)
                            .offset(y: offsetBotella)
                        
                        Image("botella")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 80)
                            .position(x: UISW * 1.39, y: UISH * 0.28)
                            .offset(y: -offsetBotella)
                        
                        Image("humo1")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 170)
                            .position(x: UISW * 1.265, y: UISH * 0.422)
                            .scaleEffect(abs(cos(offsetHumo1 * 0.06)), anchor: .trailing)
                        
                        Image("humo2")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 170)
                            .position(x: UISW * 1.316, y: UISH * 0.476)
                            .scaleEffect(abs(cos(offsetHumo1 * 0.05)), anchor: .trailing)
                        
                        Image("craneo1")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 45)
                            .position(x: UISW * 1.13, y: UISH * 0.535)
                            .offset(y: offsetHumo1 + 10)
                            .scaleEffect(abs(cos(offsetHumo1 * 0.04)), anchor: .trailing)
                        
                        Image("craneo2")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 45)
                            .position(x: UISW * 1.4, y: UISH * 0.4)
                            .offset(y: -offsetHumo1 + 10)
                            .scaleEffect(abs(cos(offsetHumo1 * 0.08)), anchor: .trailing)
                        
                        Image("mancha1")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 170)
                            .position(x: UISW * 0.23, y: UISH * 0.36)
                            .opacity(appData.isLevel1Complete ? 0 : 1)
                        
                        Button{
                            withAnimation (.smooth(duration: 0.8)){
                                isTapped1 = true
                                isPopUp = true
                            }
                        } label: {
                            Image("1 3")
                                .resizable()
                                .scaledToFit()
                                
                        }.frame(width: 80)
                            .position(x: UISW * 0.24, y: UISH * 0.3)
                            .offset(y: offsetLevels)
                        
                        Image("mancha2")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 280)
                            .position(x: UISW * 0.287, y: UISH * 0.697)
                            .opacity(appData.isLevel2Complete ? 0 : 1)
                        
                        Button {
                            withAnimation (.smooth(duration: 0.8)){
                                isTapped2 = true
                                isPopUp = true
                            }
                        } label : {
                            Image("2 3")
                                .resizable()
                                .scaledToFit()
                                
                        }.frame(width: 80)
                            .position(x: UISW * 0.315, y: UISH * 0.6)
                            .offset(y: offsetLevels)

                        Button{
                            withAnimation (.smooth(duration: 0.8)){
                                isTapped5 = true
                                isPopUp = true
                            }
                        } label :{
                            Image("5 3")
                                .resizable()
                                .scaledToFit()
                                
                        }.frame(width: 80)
                            .position(x: UISW * 1.03, y: UISH * 0.74)
                            .offset(y: offsetLevels)
                        
                        Image("mancha3")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 380)
                            .position(x: UISW * 0.79, y: UISH * 0.56)
                            .opacity(appData.isLevel3Complete ? 0 : 1)
                        
                        Button {
                            withAnimation (.smooth(duration: 0.8)){
                                isTapped3 = true
                                isPopUp = true
                            }
                        } label: {
                            Image("3 3")
                                .resizable()
                                .scaledToFit()


                        }.frame(width: 80)
                            .position(x: UISW * 0.79, y: UISH * 0.42)
                            .offset(y: offsetLevels)
                        
                        Button {
                            withAnimation (.spring(duration: 0.8)){
                                isTapped4 = true
                                isPopUp = true
                            }
                        } label : {
                            Image("4 3")
                                .resizable()
                                .scaledToFit()

                        }.frame(width: 80)
                            .position(x: UISW * 1.11, y: UISH * 0.2)
                            .offset(y: offsetLevels)
                        
                    }.onAppear{
                        let anchorPoint = UnitPoint(x: 250 / UIScreen.main.bounds.width, y: 0)
                        proxy.scrollTo(1, anchor: anchorPoint)
                    }
                }
            }
            
            Button{
                withAnimation (.easeInOut(duration: 0.5)){
                    appData.isMissions = true
                }
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                    withAnimation (.easeInOut(duration: 0.3)){
                        appData.isMissionsShowed = true
                    }
                }
            } label: {
                ZStack {
                    Image("missionBtn")
                        .resizable()
                        .scaledToFit()

                }
            }.frame(width: 134)
                .position(x:appData.UISW * 0.51, y:appData.UISH * 0.075)
            
            Button{
                withAnimation (.easeInOut(duration: 0.5)){
                    appData.isCoinStore = true
                }
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                    withAnimation (.easeInOut(duration: 0.3)){
                        appData.isCoinStoreShowed = true
                    }
                }
            } label: {
                ZStack {
                    Image("coinButton")
                        .resizable()
                        .scaledToFit()
                        
                    Text(String(appData.coinsAmmount))
                        .font(.custom("RifficFree-Bold", size: 20))
                        .foregroundStyle(.white)
                        .offset(x: 23, y: 1)
                }
            }.frame(width: 115)
                .position(x:appData.UISW * 0.923, y:appData.UISH * 0.075)
            
            
            Button{
                withAnimation (.easeInOut(duration: 0.5)){
                    appData.isBottleStore = true
                }
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                    withAnimation (.easeInOut(duration: 0.3)){
                        appData.isBottleStoreShowed = true
                    }
                }
            } label:{
                ZStack {
                    Image("bottleButton")
                        .resizable()
                        .scaledToFit()
                        
                    Text(String(appData.bottlesAmmount))
                        .font(.custom("RifficFree-Bold", size: 20))
                        .foregroundStyle(.white)
                        .offset(x: 16, y: 8)
                }
            }.frame(width: 103)
                .position(x:appData.UISW * 0.81, y:appData.UISH * 0.068)
            
            ZStack {
                Image("icon2")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 200)
                
                if appData.isLevel1Complete == false && appData.isLevel2Complete == false && appData.isLevel3Complete == false {
                    RoundedRectangle(cornerRadius: 30)
                        .frame(width: 90, height: 20)
                        .foregroundColor(.green)
                        .offset(x: 50)

                    Text("100%")
                        .font(.custom("RifficFree-Bold", size: 13))
                        .foregroundStyle(.white)
                        .offset(x: -16, y: 0)

                } else if
                    (appData.isLevel1Complete ? 1 : 0) +
                    (appData.isLevel2Complete ? 1 : 0) +
                    (appData.isLevel3Complete ? 1 : 0) == 1 {

                    RoundedRectangle(cornerRadius: 30)
                        .frame(width: 72, height: 20)
                        .foregroundColor(.green)
                        .offset(x: 59)

                    Text("80%")
                        .font(.custom("RifficFree-Bold", size: 18))
                        .foregroundStyle(.white)
                        .offset(x: -13, y: 1)

                } else if
                    (appData.isLevel1Complete ? 1 : 0) +
                    (appData.isLevel2Complete ? 1 : 0) +
                    (appData.isLevel3Complete ? 1 : 0) == 2 {

                    RoundedRectangle(cornerRadius: 30)
                        .frame(width: 54, height: 20)
                        .foregroundColor(.green)
                        .offset(x: 67)

                    Text("60%")
                        .font(.custom("RifficFree-Bold", size: 18))
                        .foregroundStyle(.white)
                        .offset(x: -13, y: 1)
                } else if
                    (appData.isLevel1Complete ? 1 : 0) +
                    (appData.isLevel2Complete ? 1 : 0) +
                    (appData.isLevel3Complete ? 1 : 0) == 3 {

                    RoundedRectangle(cornerRadius: 30)
                        .frame(width: 36, height: 20)
                        .foregroundColor(.green)
                        .offset(x: 76)

                    Text("40%")
                        .font(.custom("RifficFree-Bold", size: 18))
                        .foregroundStyle(.white)
                        .offset(x: -13, y: 1)
                }
                

            }.position(x:appData.UISW * 0.67, y:appData.UISH * 0.077)
            
//            Text(String(isLevel1))
//                .font(.custom("RifficFree-Bold", size: 18))
//                .foregroundStyle(.white)
//                .offset(x: 18, y: 1)
            
            Rectangle()
                .foregroundColor(.black)
                .frame(width: UISW, height: UISH)
                .opacity(isPopUp ? 0.6 : 0)
                .onTapGesture {
                    withAnimation (.spring(duration: 0.5)){
                        isPopUp = false
                        isTapped1 = false
                        isTapped2 = false
                        isTapped3 = false
                        isTapped4 = false
                        isTapped5 = false
                    }
                }
            
            ZStack {
                Image("pop-n1")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 800)
                
                Button{
                    withAnimation (.spring(duration: 0.5)){
                        isPopUp = false
                        isTapped1 = false
                        isTapped2 = false
                        isTapped3 = false
                        isTapped4 = false
                        isTapped5 = false
                    }
                    appData.isLevel1 = true
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                        withAnimation (.easeInOut(duration: 0.5)){
                            appData.isLevel1Showed = true
                        }
                    }
                } label: {
                    Image("joinBtn")
                        .resizable()
                        .scaledToFit()
                        
                }.frame(width: 130)
                    .position(x: UISW * 0.5, y: UISH * 0.78)
            }
                .position(x: UISW * 0.5, y: UISH * 0.5)
                .offset(y: isTapped1 ? 0 : UISH * 2)

            
            ZStack {
                Image("pop-n2")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 800)
                
                Button{
                    withAnimation (.spring(duration: 0.5)){
                        isPopUp = false
                        isTapped1 = false
                        isTapped2 = false
                        isTapped3 = false
                        isTapped4 = false
                        isTapped5 = false
                    }
                    appData.isLevel2 = true
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                        withAnimation (.easeInOut(duration: 0.5)){
                            appData.isLevel2Showed = true
                        }
                    }
                } label: {
                    Image("joinBtn")
                        .resizable()
                        .scaledToFit()
                        
                }.frame(width: 130)
                    .position(x: UISW * 0.5, y: UISH * 0.78)
            }
                .position(x: UISW * 0.5, y: UISH * 0.5)
                .offset(y: isTapped2 ? 0 : UISH * 2)
            
            ZStack {
                Image("pop-n3")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 800)
                
                Button{
                    withAnimation (.spring(duration: 0.5)){
                        isPopUp = false
                        isTapped1 = false
                        isTapped2 = false
                        isTapped3 = false
                        isTapped4 = false
                        isTapped5 = false
                    }
                    appData.isLevel3 = true
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                        withAnimation (.easeInOut(duration: 0.5)){
                            appData.isLevel3Showed = true
                        }
                    }
                } label: {
                    Image("joinBtn")
                        .resizable()
                        .scaledToFit()
                        
                }.frame(width: 130)
                    .position(x: UISW * 0.5, y: UISH * 0.78)
            }
                .position(x: UISW * 0.5, y: UISH * 0.5)
                .offset(y: isTapped3 ? 0 : UISH * 2)
            
            ZStack {
                Image("pop-n4")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 800)
                
                Button{
                    withAnimation (.spring(duration: 0.5)){
                        isPopUp = false
                        isTapped1 = false
                        isTapped2 = false
                        isTapped3 = false
                        isTapped4 = false
                        isTapped5 = false
                    }
                } label: {
                    Image("comingBtn")
                        .resizable()
                        .scaledToFit()
                       
                } .frame(width: 240)
                    .position(x: UISW * 0.5, y: UISH * 0.78)
            }
                .position(x: UISW * 0.5, y: UISH * 0.5)
                .offset(y: isTapped4 ? 0 : UISH * 2)
            
            ZStack {
                Image("pop-n5")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 800)
                
                Button{
                    withAnimation (.spring(duration: 0.5)){
                        isPopUp = false
                        isTapped1 = false
                        isTapped2 = false
                        isTapped3 = false
                        isTapped4 = false
                        isTapped5 = false
                    }
                } label: {
                    Image("comingBtn")
                        .resizable()
                        .scaledToFit()
                       
                } .frame(width: 240)
                    .position(x: UISW * 0.5, y: UISH * 0.78)
            }
                .position(x: UISW * 0.5, y: UISH * 0.5)
                .offset(y: isTapped5 ? 0 : UISH * 2)
            
//            Image("xmark")
//                .resizable()
//                .scaledToFit()
//                .frame(width: 60)
//                .position(x: UISW * 0.21, y: UISH * 0.24)
//                .offset(y: isPopUp ? 0 : UISH * 2)
//                .onTapGesture {
//                    withAnimation (.spring(duration: 0.5)){
//                        isPopUp = false
//                        isTapped1 = false
//                        isTapped5 = false
//                    }
//                }
            
            Button {
                withAnimation (.easeInOut(duration: 0.5)){
                    appData.isMapViewShowed = false
                }
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.6) {
                    appData.isMapView = false
                }
            } label: {
                Image("menuCartel")
                    .resizable()
                    .scaledToFit()
                    .rotationEffect(.degrees(10))
            }
                .frame(width: 200)
                .position(x:appData.UISW * 0.13, y: appData.UISH * 0.94)

            Circle()
                .fill(.clear)
                .allowsHitTesting(false)
                .onAppear{
                    SoundManager.instance.stopSound()
                    SoundManager.instance.playSound(sound: .mapa)
                }
            
            if appData.isLevel1 {
                Act_1()
                    .offset(y: appData.isLevel1Showed ? 0 : appData.UISH * 1.5)
            } else if appData.isLevel2 {
                Act_2()
                    .offset(y: appData.isLevel2Showed ? 0 : appData.UISH * 1.5)
            } else if appData.isLevel3 {
                Act_3()
                    .offset(y: appData.isLevel3Showed ? 0 : appData.UISH * 1.5)
            } else if appData.isCoinStore {
                ZStack{
                    Rectangle()
                        .foregroundStyle(.black.opacity(0.5))
                        .onTapGesture {
                            withAnimation (.easeInOut(duration: 0.5)){
                                appData.isCoinStoreShowed = false
                            }
                            DispatchQueue.main.asyncAfter(deadline: .now() + 0.4) {
                                withAnimation (.easeInOut(duration: 0.2)){
                                    appData.isCoinStore = false
                                }
                            }
                        }
                    BuyAHeroView()
                        .offset(x: appData.isCoinStoreShowed ? 0 : appData.UISW * 1.5)
                }.frame(width: appData.UISW, height: appData.UISH)
            } else if appData.isBottleStore{
                
                ZStack {
                    Rectangle()
                        .foregroundStyle(.black.opacity(0.5))
                        .onTapGesture {
                            withAnimation (.easeInOut(duration: 0.5)){
                                appData.isBottleStoreShowed = false
                            }
                            DispatchQueue.main.asyncAfter(deadline: .now() + 0.4) {
                                withAnimation (.easeInOut(duration: 0.2)){
                                    appData.isBottleStore = false
                                }
                            }
                        }
                    
                    Image("botellaInfo")
                        .resizable()
                        .scaledToFit()
                        .frame(width: appData.UISW * 0.7)
                        .offset(y: appData.isBottleStoreShowed ? 0 : appData.UISH * 1.5)
                    
                    Button{
                        withAnimation (.easeInOut(duration: 0.5)){
                            appData.isBottleStoreShowed = false
                        }
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.4) {
                            withAnimation (.easeInOut(duration: 0.2)){
                                appData.isBottleStore = false
                            }
                        }
                    } label: {
                        Image("helpBtn")
                            .resizable()
                            .scaledToFit()
                    }.frame(width: 150)
                        .position(x:appData.UISW * 0.5, y: appData.UISH * 0.87)
                        .offset(y: appData.isBottleStoreShowed ? 0 : appData.UISH * 1.5)

                }
                
            } else if appData.isMissions {
                Rectangle()
                    .foregroundStyle(.black.opacity(0.5))
                    .onTapGesture {
                        withAnimation (.easeInOut(duration: 0.5)){
                            appData.isMissionsShowed = false
                        }
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.4) {
                            withAnimation (.easeInOut(duration: 0.2)){
                                appData.isMissions = false
                            }
                        }
                    }
                
                ZStack{
                    Image("missionPopup")
                        .resizable()
                        .scaledToFit()
                    
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 40) {
                            Image("pollution")
                                .resizable()
                                .scaledToFit()
                                .frame(width: appData.UISW * 0.5)
                            Image("habitat")
                                .resizable()
                                .scaledToFit()
                                .frame(width: appData.UISW * 0.5)
                            Image("corporations")
                                .resizable()
                                .scaledToFit()
                                .frame(width: appData.UISW * 0.5)
                                .offset(y: 13)
                        }
                    }
                        .frame(width: appData.UISW * 0.72)
                        .position(x: appData.UISW * 0.4, y: appData.UISH * 0.66)
                        
                    Button{
                        withAnimation (.easeInOut(duration: 0.5)){
                            appData.isMissionsShowed = false
                        }
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.4) {
                            withAnimation (.easeInOut(duration: 0.2)){
                                appData.isMissions = false
                            }
                        }
                    } label: {
                        Image("helpBtn")
                            .resizable()
                            .scaledToFit()
                    }.frame(width: 200)
                        .position(x:appData.UISW * 0.41, y: appData.UISH * 0.89)
                        
                }.frame(width: appData.UISW * 0.8)
                    .offset(y: appData.isMissionsShowed ? 0 : appData.UISH * 1.5)
            }
            
            
        }.ignoresSafeArea()
            .onAppear{
                withAnimation(Animation.easeInOut(duration: 1.3).repeatForever()) {
                    offsetBote2 += 12
                    if offsetBote2 > 6 {
                        offsetBote2 = -6
                    }
                }
                withAnimation(Animation.easeInOut(duration: 0.2).repeatForever()) {
                    offsetLiquido += 4
                    if offsetLiquido > 2 {
                        offsetLiquido = -2
                    }
                }
                withAnimation(Animation.easeInOut(duration: 1).repeatForever()) {
                    offsetBotella -= 4
                    if offsetBotella > 2 {
                        offsetBotella = 2
                    }
                }
                withAnimation(Animation.easeInOut(duration: 2).repeatForever()) {
                    offsetHumo1 -= 4
                    if offsetHumo1 > 2 {
                        offsetHumo1 = 2
                    }
                }
                withAnimation(Animation.easeInOut(duration: 1.2).repeatForever()) {
                    offsetLevels -= 4
                    if offsetLevels > 2 {
                        offsetLevels = 2
                    }
                }
            }
    }
}

struct Mapa_Previews: PreviewProvider {
    static var previews: some View {
        return MapaView().environmentObject(AppData())
    }
}
