import SwiftUI

struct Act_1: View {
    
    @EnvironmentObject var appData: AppData

    @State private var stepTutorial: Int = 0
    
    @State private var basuraPapel: Int = 0
    @State private var basuraMetal: Int = 0
    @State private var basuraPlastico: Int = 0
    @State private var basuraCarton: Int = 0
    @State private var basuraOrganico: Int = 0
    @State private var basuraVidrio: Int = 0
    
    @State private var isPopMetal: Bool = false
    @State private var isPopPapel: Bool = false
    @State private var isPopPlastico: Bool = false
    @State private var isPopCarton: Bool = false
    @State private var isPopOrganico: Bool = false
    @State private var isPopVidrio: Bool = false

    @State private var rotateFinger: Bool = false
    
    @State private var dialoguePapel: Bool = false
    @State private var dialogueMetal: Bool = false
    @State private var dialoguePlastico: Bool = false
    @State private var dialogueCaron: Bool = false
    @State private var dialogueOrganico: Bool = false
    @State private var dialogueVidrio: Bool = false
    
    @State private var objeto1XOffset: CGFloat = .zero
    @State private var objeto1YOffset: CGFloat = .zero
    
    @State private var objeto2XOffset: CGFloat = .zero
    @State private var objeto2YOffset: CGFloat = .zero
    
    @State private var objeto3XOffset: CGFloat = .zero
    @State private var objeto3YOffset: CGFloat = .zero
    
    @State private var objeto4XOffset: CGFloat = .zero
    @State private var objeto4YOffset: CGFloat = .zero
    
    @State private var objeto5XOffset: CGFloat = .zero
    @State private var objeto5YOffset: CGFloat = .zero
    
    @State private var objeto6XOffset: CGFloat = .zero
    @State private var objeto6YOffset: CGFloat = .zero
    
    @State private var objeto7XOffset: CGFloat = .zero
    @State private var objeto7YOffset: CGFloat = .zero
    
    @State private var objeto8XOffset: CGFloat = .zero
    @State private var objeto8YOffset: CGFloat = .zero
    
    @State private var objeto9XOffset: CGFloat = .zero
    @State private var objeto9YOffset: CGFloat = .zero
    
    @State private var objeto10XOffset: CGFloat = .zero
    @State private var objeto10YOffset: CGFloat = .zero
    
    @State private var objeto11XOffset: CGFloat = .zero
    @State private var objeto11YOffset: CGFloat = .zero
    
    @State private var objeto12XOffset: CGFloat = .zero
    @State private var objeto12YOffset: CGFloat = .zero

    @State private var position1: CGPoint = CGPoint(x: UIScreen.main.bounds.width * 0.2, y: UIScreen.main.bounds.height * 0.52)
    
    @State private var position2: CGPoint = CGPoint(x: UIScreen.main.bounds.width * 0.5, y: UIScreen.main.bounds.height * 0.54)
    
    @State private var position3: CGPoint = CGPoint(x: UIScreen.main.bounds.width * 0.8, y: UIScreen.main.bounds.height * 0.55)
    
    @State private var dialogue1: CGPoint = CGPoint(x: UIScreen.main.bounds.width * 0.2, y: UIScreen.main.bounds.height * 0.52)
    @State private var dialogue2: CGPoint = CGPoint(x: UIScreen.main.bounds.width * 0.5, y: UIScreen.main.bounds.height * 0.54)
    @State private var dialogue3: CGPoint = CGPoint(x: UIScreen.main.bounds.width * 0.8, y: UIScreen.main.bounds.height * 0.55)

    @State private var is3Colliding: Bool = false
    @State private var is7Colliding: Bool = false
    @State private var is1Colliding: Bool = false
    @State private var is4Colliding: Bool = false
    @State private var is21Colliding: Bool = false
    @State private var is26Colliding: Bool = false
    @State private var is9Colliding: Bool = false
    @State private var is14Colliding: Bool = false
    @State private var is15Colliding: Bool = false
    @State private var is18Colliding: Bool = false
    @State private var is19Colliding: Bool = false
    @State private var is27Colliding: Bool = false

    @State private var is3In: Bool = false
    @State private var is7In: Bool = false
    @State private var is1In: Bool = false
    @State private var is4In: Bool = false
    @State private var is21In: Bool = false
    @State private var is26In: Bool = false
    @State private var is9In: Bool = false
    @State private var is14In: Bool = false
    @State private var is15In: Bool = false
    @State private var is18In: Bool = false
    @State private var is19In: Bool = false
    @State private var is27In: Bool = false
    
    //MARK: Vars for trashPositions
    
    @State private var initialPositionPapel: CGPoint? = nil
    @State private var initialPositionOrganico: CGPoint? = nil
    @State private var initialPositionVidrio: CGPoint? = nil
    @State private var fulfilledConditionsOrganico: [CGPoint] = []
    @State private var fulfilledConditionsVidrio: [CGPoint] = []

    @State private var trash3: CGPoint = CGPoint(x: UIScreen.main.bounds.width * 0.34, y: UIScreen.main.bounds.height * 0.75)
    @State private var trash7: CGPoint = CGPoint(x: UIScreen.main.bounds.width * 0.46, y: UIScreen.main.bounds.height * 0.79)
    @State private var trash1: CGPoint = CGPoint(x: UIScreen.main.bounds.width * 0.4, y: UIScreen.main.bounds.height * 0.76)
    @State private var trash4: CGPoint = CGPoint(x: UIScreen.main.bounds.width * 0.64, y: UIScreen.main.bounds.height * 0.75)
    @State private var trash21: CGPoint = CGPoint(x: UIScreen.main.bounds.width * 0.54, y: UIScreen.main.bounds.height * 0.76)
    @State private var trash26: CGPoint = CGPoint(x: UIScreen.main.bounds.width * 0.54, y: UIScreen.main.bounds.height * 0.79)
    @State private var trash9: CGPoint = CGPoint(x: UIScreen.main.bounds.width * 0.56, y: UIScreen.main.bounds.height * 0.79)
    @State private var trash14: CGPoint = CGPoint(x: UIScreen.main.bounds.width * 0.45, y: UIScreen.main.bounds.height * 0.79)
    @State private var trash15: CGPoint = CGPoint(x: UIScreen.main.bounds.width * 0.31, y: UIScreen.main.bounds.height * 0.79)
    @State private var trash18: CGPoint = CGPoint(x: UIScreen.main.bounds.width * 0.37, y: UIScreen.main.bounds.height * 0.78)
    @State private var trash19: CGPoint = CGPoint(x: UIScreen.main.bounds.width * 0.71, y: UIScreen.main.bounds.height * 0.76)
    @State private var trash27: CGPoint = CGPoint(x: UIScreen.main.bounds.width * 0.596, y: UIScreen.main.bounds.height * 0.78)
    
    var body: some View {
        ZStack{
            Image("fondoAct1")
                .resizable()
                .scaledToFill()
                .frame(width: appData.UISW * 1.4)
                .position(x: appData.UISW * 0.54, y: appData.UISH * 0.54)
            
            Image("metalText")
                .resizable()
                .scaledToFit()
                .frame(width: dialogueMetal ? 350 : 0)
                .position(dialogue1)
                .offset(y: dialogueMetal ? -220 : 0)
            
            Image("papelText")
                .resizable()
                .scaledToFit()
                .frame(width: dialoguePapel ? 350 : 0)
                .position(initialPositionPapel ?? CGPoint(x: appData.UISW * 1.5, y: position1.y))
                .offset(y: dialoguePapel ? -220 : 0)
            
            Image("organicoText")
                .resizable()
                .scaledToFit()
                .frame(width: dialogueOrganico ? 350 : 0)
                .position(initialPositionOrganico ?? CGPoint(x: appData.UISW * 1.5, y: position1.y))
                .offset(y: dialogueOrganico ? -220 : 0)
            
            Image("vidrioText")
                .resizable()
                .scaledToFit()
                .frame(width: dialogueVidrio ? 350 : 0)
                .position(initialPositionVidrio ?? CGPoint(x: appData.UISW * 1.5, y: position1.y))
                .offset(y: dialogueVidrio ? -220 : 0)
            
            Image("plasticosText")
                .resizable()
                .scaledToFit()
                .frame(width: dialoguePlastico ? 350 : 0)
                .position(dialogue2)
                .offset(y: dialoguePlastico ? -200 : 0)
            
            Image("cartonText")
                .resizable()
                .scaledToFit()
                .frame(width: dialogueCaron ? 350 : 0)
                .position(dialogue3)
                .offset(y: dialogueCaron ? -220 : 0)
            
            if basuraMetal == 2 || basuraPlastico == 2 || basuraCarton == 2 {
                Circle()
                    .foregroundStyle(.clear)
                    .allowsHitTesting(false)
                    .onAppear{
                        if initialPositionPapel == nil {
                            initialPositionPapel = basuraMetal == 2 ? position1 :
                            basuraPlastico == 2 ? position2 :
                            basuraCarton == 2 ? position3 :
                            CGPoint(x: appData.UISW * 1.5, y: position1.y)
                        }
                    }
            }
            
            ZStack {
                Image("papel")
                    .resizable()
                    .scaledToFit()
                
                Text("\(basuraPapel)/2")
                    .font(.custom("RifficFree-Bold", size: 17))
                    .opacity(0.5)
                    .offset(y: -126)
                    
            }.frame(width: 250)
                .position(initialPositionPapel ?? {
                    let newPosition = basuraMetal == 2 ? position1 :basuraPlastico == 2 ? position2 :basuraCarton == 2 ? position3 :CGPoint(x: appData.UISW * 1.5, y: position1.y)
                    if initialPositionPapel == nil {
                        initialPositionPapel = newPosition
                    }
                    return newPosition
                }())
                .onTapGesture {
                    withAnimation (.easeInOut(duration: 0.2)){
                        dialoguePapel = true
                    }
                    DispatchQueue.main.asyncAfter(deadline: .now() + 5) {
                        withAnimation (.easeInOut(duration: 0.5)){
                            dialoguePapel = false
                        }
                    }
                }
                .zIndex(0.5)
            
            ZStack {
                Image("organico")
                    .resizable()
                    .scaledToFit()
                
                Text("\(basuraOrganico)/2")
                    .font(.custom("RifficFree-Bold", size: 17))
                    .opacity(0.5)
                    .offset(y: -126)
                    
            }.frame(width: 250)
                .position(initialPositionOrganico ?? CGPoint(x: appData.UISW * 1.5, y: position1.y))
                .onTapGesture {
                    withAnimation (.easeInOut(duration: 0.2)){
                        dialogueOrganico = true
                    }
                    DispatchQueue.main.asyncAfter(deadline: .now() + 5) {
                        withAnimation (.easeInOut(duration: 0.5)){
                            dialogueOrganico = false
                        }
                    }
                }
                .zIndex(0.5)
            
            ZStack {
                Image("vidrio")
                    .resizable()
                    .scaledToFit()
                
                Text("\(basuraVidrio)/2")
                    .font(.custom("RifficFree-Bold", size: 17))
                    .opacity(0.5)
                    .offset(y: -126)
                    
            }.frame(width: 250)
                .position(initialPositionVidrio ?? CGPoint(x: appData.UISW * 1.5, y: position1.y))
                .onTapGesture {
                    withAnimation (.easeInOut(duration: 0.2)){
                        dialogueVidrio = true
                    }
                    DispatchQueue.main.asyncAfter(deadline: .now() + 5) {
                        withAnimation (.easeInOut(duration: 0.5)){
                            dialogueVidrio = false
                        }
                    }
                }
                .zIndex(0.5)
            
            ZStack {
                Image("metal")
                    .resizable()
                    .scaledToFit()
                
                Text("\(basuraMetal)/2")
                    .font(.custom("RifficFree-Bold", size: 17))
                    .opacity(0.5)
                    .offset(y: -126)
                    
            }.frame(width: 250)
                .position(position1)
                .onTapGesture {
                    withAnimation (.easeInOut(duration: 0.2)){
                        dialogueMetal = true
                    }
                    DispatchQueue.main.asyncAfter(deadline: .now() + 5) {
                        withAnimation (.easeInOut(duration: 0.5)){
                            dialogueMetal = false
                        }
                    }
                }
                .zIndex(0.5)
                .offset(x: basuraMetal == 2 ? -appData.UISW * 1 : 0)
            
            ZStack {
                Image("plastico")
                    .resizable()
                    .scaledToFit()
                    
                Text("\(basuraPlastico)/2")
                    .font(.custom("RifficFree-Bold", size: 17))
                    .opacity(0.5)
                    .offset(x: -8,y: -108)
                
            }.frame(width: 250)
                .position(position2)
                .onTapGesture {
                    withAnimation (.easeInOut(duration: 0.2)){
                        dialoguePlastico = true
                    }
                    DispatchQueue.main.asyncAfter(deadline: .now() + 5) {
                        withAnimation (.easeInOut(duration: 0.5)){
                            dialoguePlastico = false
                        }
                    }
                }
                .offset(x: basuraPlastico == 2 ? -appData.UISW * 1 : 0)
            
            ZStack {
                Image("carton")
                    .resizable()
                    .scaledToFit()
                
                Text("\(basuraPlastico)/2")
                    .font(.custom("RifficFree-Bold", size: 17))
                    .opacity(0.5)
                    .offset(x: 2,y: -125)

            }.frame(width: 250)
                .position(position3)
                .onTapGesture {
                    withAnimation (.easeInOut(duration: 0.2)){
                        dialogueCaron = true
                    }
                    DispatchQueue.main.asyncAfter(deadline: .now() + 5) {
                        withAnimation (.easeInOut(duration: 0.5)){
                            dialogueCaron = false
                        }
                    }
                }
                .offset(x: basuraCarton == 2 ? -appData.UISW * 1 : 0)
            
//            Rectangle()
//                .frame(width: 250, height: 310)
//                .position(x: (initialPositionPapel?.x ?? -1000),
//                          y: (initialPositionPapel?.y ?? -1000))
            
//            Rectangle()
//                .foregroundStyle(.mint)
//                .frame(width: 60, height: 70)
//                .position(x: trash18.x + objeto8XOffset, y: trash18.y + objeto8YOffset)
            
            Image("3")
                .resizable()
                .scaledToFit()
                .frame(width: 120)
                .position(trash3)
                .offset(x: objeto2XOffset, y: objeto2YOffset)
                .opacity(is3In ? 0 : 1)
                .gesture(
                        DragGesture()
                            .onChanged { value in
                                objeto2XOffset = value.translation.width
                                objeto2YOffset = value.translation.height
                            }
                            .onEnded { _ in
                                
                                let bote1Frame = CGRect(
                                    x: (position1.x - 130),
                                    y: (position1.y - 155),
                                    width: 260,
                                    height: 310
                                )
                                
                                let basuraFrame = CGRect(
                                    x: ((appData.UISW * 0.34) + objeto2XOffset) - 60,
                                    y: ((appData.UISH * 0.75) + objeto2YOffset) - 25,
                                    width: 120,
                                    height: 50
                                )
                                
                                is3Colliding = basuraFrame.intersects(bote1Frame)
                                
                                if is3Colliding{
                                    withAnimation(.bouncy(duration: 0.6)) {
                                        objeto2XOffset = 0
                                        objeto2YOffset = -200
                                        trash3 = position1
                                    }
                                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.7) {
                                        withAnimation (.bouncy(duration: 0.3)){
                                            is3In = true
                                            objeto2YOffset = 0
                                        }
                                        withAnimation(.bouncy(duration: 2)) {
                                            basuraMetal += 1
                                            updatePositionOrganico()
                                            updatePositionVidrio()
                                        }
                                    }
                                } else {
                                    withAnimation(.spring(duration: 0.5)) {
                                        objeto2XOffset = 0
                                        objeto2YOffset = 0
                                    }
                                }
                            }
                    )
                .zIndex(is3In ? 0.4 : 1.0)

            Image("7")
                .resizable()
                .scaledToFit()
                .frame(width: 150)
                .position(trash7)
                .offset(x: objeto4XOffset, y: objeto4YOffset)
                .opacity(is7In ? 0 : 1)
                .zIndex(is7In ? 0.4 : 1.0)
                .gesture(
                    DragGesture()
                        .onChanged { value in
                            objeto4XOffset = value.translation.width
                            objeto4YOffset = value.translation.height
                        }
                        .onEnded { _ in
                            
                            let bote1Frame = CGRect(
                                x: (position3.x - 130),
                                y: (position3.y - 155),
                                width: 260,
                                height: 310
                            )
                            
                            let basuraFrame = CGRect(
                                x: ((trash7.x) + objeto4XOffset) - 75,
                                y: ((trash7.y) + objeto4YOffset) - 50,
                                width: 150,
                                height: 100
                            )
                            
                            is7Colliding = basuraFrame.intersects(bote1Frame)
                            
                            if is7Colliding{
                                withAnimation(.bouncy(duration: 0.6)) {
                                    objeto4XOffset = 0
                                    objeto4YOffset = -220
                                    trash7 = position3
                                }
                                DispatchQueue.main.asyncAfter(deadline: .now() + 0.7) {
                                    withAnimation (.bouncy(duration: 0.3)){
                                        is7In = true
                                        objeto4YOffset = 0
                                    }
                                    withAnimation(.bouncy(duration: 2)) {
                                        basuraCarton += 1
                                        updatePositionOrganico()
                                        updatePositionVidrio()
                                    }
                                }
                            } else {
                                withAnimation(.spring(duration: 0.5)) {
                                    objeto4XOffset = 0
                                    objeto4YOffset = 0
                                }
                            }
                        }
                )

            Image("1")
                .resizable()
                .scaledToFit()
                .frame(width: 50)
                .position(trash1)
                .offset(x: objeto1XOffset, y: objeto1YOffset)
                .opacity(is1In ? 0 : 1)
                .zIndex(is1In ? 0.4 : 1.0)
                .gesture(
                        DragGesture()
                            .onChanged { value in
                                objeto1XOffset = value.translation.width
                                objeto1YOffset = value.translation.height
                            }
                            .onEnded { _ in
                                
                                let bote1Frame = CGRect(
                                    x: (position1.x - 130),
                                    y: (position1.y - 155),
                                    width: 260,
                                    height: 310
                                )
                                
                                let basuraFrame = CGRect(
                                    x: ((trash1.x) + objeto1XOffset) - 30,
                                    y: ((trash1.y) + objeto1YOffset) - 45,
                                    width: 60,
                                    height: 90
                                )
                                
                                is1Colliding = basuraFrame.intersects(bote1Frame)
                                
                                if is1Colliding{
                                    withAnimation(.bouncy(duration: 0.6)) {
                                        objeto1XOffset = 0
                                        objeto1YOffset = -210
                                        trash1 = position1
                                    }
                                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.7) {
                                        withAnimation (.bouncy(duration: 0.3)){
                                            is1In = true
                                            objeto1YOffset = 0
                                        }
                                        withAnimation(.bouncy(duration: 2)) {
                                            basuraMetal += 1
                                            updatePositionOrganico()
                                            updatePositionVidrio()
                                        }
                                    }
                                } else {
                                    withAnimation(.spring(duration: 0.5)) {
                                        objeto1XOffset = 0
                                        objeto1YOffset = 0
                                    }
                                }
                            }
                    )

            Image("4")
                .resizable()
                .scaledToFit()
                .frame(width: 120)
                .position(trash4)
                .offset(x: objeto3XOffset, y: objeto3YOffset)
                .opacity(is4In ? 0 : 1)
                .zIndex(is4In ? 0.4 : 1.0)
                .gesture(
                    DragGesture()
                        .onChanged { value in
                            objeto3XOffset = value.translation.width
                            objeto3YOffset = value.translation.height
                        }
                        .onEnded { _ in
                            
                            let bote1Frame = CGRect(
                                x: (position3.x - 130),
                                y: (position3.y - 155),
                                width: 260,
                                height: 310
                            )
                            
                            let basuraFrame = CGRect(
                                x: ((trash4.x) + objeto3XOffset) - 65,
                                y: ((trash4.y) + objeto3YOffset) - 60,
                                width: 130,
                                height: 120
                            )
                            
                            is4Colliding = basuraFrame.intersects(bote1Frame)
                            
                            if is4Colliding{
                                withAnimation(.bouncy(duration: 0.6)) {
                                    objeto3XOffset = 0
                                    objeto3YOffset = -220
                                    trash4 = position3
                                }
                                DispatchQueue.main.asyncAfter(deadline: .now() + 0.7) {
                                    withAnimation (.bouncy(duration: 0.3)){
                                        is4In = true
                                        objeto3YOffset = 0
                                    }
                                    withAnimation(.bouncy(duration: 2)) {
                                        basuraCarton += 1
                                        updatePositionOrganico()
                                        updatePositionVidrio()
                                    }
                                }
                            } else {
                                withAnimation(.spring(duration: 0.5)) {
                                    objeto3XOffset = 0
                                    objeto3YOffset = 0
                                }
                            }
                        }
                )

            Image("21")
                .resizable()
                .scaledToFit()
                .frame(width: 40)
                .position(trash21)
                .offset(x: objeto10XOffset, y: objeto10YOffset)
                .opacity(is21In ? 0 : 1)
                .zIndex(is21In ? 0.4 : 1.0)
                .gesture(
                    DragGesture()
                        .onChanged { value in
                            objeto10XOffset = value.translation.width
                            objeto10YOffset = value.translation.height
                        }
                        .onEnded { _ in
                            
                            let bote1Frame = CGRect(
                                x: ((initialPositionVidrio?.x ?? -1000) - 130),
                                y: (((initialPositionVidrio?.y ?? -1000) - 155)),
                                width: 260,
                                height: 310
                            )
                            
                            let basuraFrame = CGRect(
                                x: ((trash21.x) + objeto10XOffset) - 30,
                                y: ((trash21.y) + objeto10YOffset) - 35,
                                width: 60,
                                height: 70
                            )
                            
                            is21Colliding = basuraFrame.intersects(bote1Frame)
                            
                            if is21Colliding{
                                withAnimation(.bouncy(duration: 0.6)) {
                                    objeto10XOffset = 0
                                    objeto10YOffset = -210
                                    trash21 = initialPositionVidrio ?? CGPoint(x: 0, y: 0)
                                }
                                DispatchQueue.main.asyncAfter(deadline: .now() + 0.7) {
                                    withAnimation (.bouncy(duration: 0.3)){
                                        is21In = true
                                        objeto10YOffset = 0
                                    }
                                    withAnimation(.bouncy(duration: 2)) {
                                        basuraVidrio += 1
                                    }
                                }
                            } else {
                                withAnimation(.spring(duration: 0.5)) {
                                    objeto10XOffset = 0
                                    objeto10YOffset = 0
                                }
                            }
                        }
                )


            Image("26")
                .resizable()
                .scaledToFit()
                .frame(width: 90)
                .position(trash26)
                .offset(x: objeto11XOffset, y: objeto11YOffset)
                .opacity(is26In ? 0 : 1)
                .zIndex(is26In ? 0.4 : 1.0)
                .gesture(
                        DragGesture()
                            .onChanged { value in
                                objeto11XOffset = value.translation.width
                                objeto11YOffset = value.translation.height
                            }
                            .onEnded { _ in
                                
                                let bote1Frame = CGRect(
                                    x: (position2.x - 130),
                                    y: (position2.y - 155),
                                    width: 260,
                                    height: 310
                                )
                                
                                let basuraFrame = CGRect(
                                    x: ((trash26.x) + objeto11XOffset) - 50,
                                    y: ((trash26.y) + objeto11YOffset) - 20,
                                    width: 100,
                                    height: 40
                                )
                                
                                is26Colliding = basuraFrame.intersects(bote1Frame)
                                
                                if is26Colliding{
                                    withAnimation(.bouncy(duration: 0.6)) {
                                        objeto11XOffset = 0
                                        objeto11YOffset = -180
                                        trash26 = position2
                                    }
                                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.7) {
                                        withAnimation (.bouncy(duration: 0.3)){
                                            is26In = true
                                            objeto11YOffset = 0
                                        }
                                        withAnimation(.bouncy(duration: 2)) {
                                            basuraPlastico += 1
                                            updatePositionOrganico()
                                            updatePositionVidrio()
                                        }
                                    }
                                } else {
                                    withAnimation(.spring(duration: 0.5)) {
                                        objeto11XOffset = 0
                                        objeto11YOffset = 0
                                    }
                                }
                            }
                    )

            Image("9")
                .resizable()
                .scaledToFit()
                .frame(width: 70)
                .position(trash9)
                .offset(x: objeto5XOffset, y: objeto5YOffset)
                .opacity(is9In ? 0 : 1)
                .zIndex(is9In ? 0.4 : 1.0)
                .gesture(
                    DragGesture()
                        .onChanged { value in
                            objeto5XOffset = value.translation.width
                            objeto5YOffset = value.translation.height
                        }
                        .onEnded { _ in
                            
                            let bote1Frame = CGRect(
                                x: ((initialPositionOrganico?.x ?? -1000) - 130),
                                y: (((initialPositionOrganico?.y ?? -1000) - 155)),
                                width: 260,
                                height: 310
                            )
                            
                            let basuraFrame = CGRect(
                                x: ((trash9.x) + objeto5XOffset) - 30,
                                y: ((trash9.y) + objeto5YOffset) - 35,
                                width: 60,
                                height: 70
                            )
                            
                            is9Colliding = basuraFrame.intersects(bote1Frame)
                            
                            if is9Colliding{
                                withAnimation(.bouncy(duration: 0.6)) {
                                    objeto5XOffset = 0
                                    objeto5YOffset = -210
                                    trash9 = initialPositionOrganico ?? CGPoint(x: 0, y: 0)
                                }
                                DispatchQueue.main.asyncAfter(deadline: .now() + 0.7) {
                                    withAnimation (.bouncy(duration: 0.3)){
                                        is9In = true
                                        objeto5YOffset = 0
                                    }
                                    withAnimation(.bouncy(duration: 2)) {
                                        basuraOrganico += 1
                                    }
                                }
                            } else {
                                withAnimation(.spring(duration: 0.5)) {
                                    objeto5XOffset = 0
                                    objeto5YOffset = 0
                                }
                            }
                        }
                )

            Image("14")
                .resizable()
                .scaledToFit()
                .frame(width: 70)
                .position(trash14)
                .offset(x: objeto6XOffset, y: objeto6YOffset)
                .opacity(is14In ? 0 : 1)
                .zIndex(is14In ? 0.4 : 1.0)
                .gesture(
                    DragGesture()
                        .onChanged { value in
                            objeto6XOffset = value.translation.width
                            objeto6YOffset = value.translation.height
                        }
                        .onEnded { _ in
                            
                            let bote1Frame = CGRect(
                                x: ((initialPositionOrganico?.x ?? -1000) - 130),
                                y: (((initialPositionOrganico?.y ?? -1000) - 155)),
                                width: 260,
                                height: 310
                            )
                            
                            let basuraFrame = CGRect(
                                x: ((trash14.x) + objeto6XOffset) - 30,
                                y: ((trash14.y) + objeto6YOffset) - 35,
                                width: 60,
                                height: 70
                            )
                            
                            is14Colliding = basuraFrame.intersects(bote1Frame)
                            
                            if is14Colliding{
                                withAnimation(.bouncy(duration: 0.6)) {
                                    objeto6XOffset = 0
                                    objeto6YOffset = -210
                                    trash14 = initialPositionOrganico ?? CGPoint(x: 0, y: 0)
                                }
                                DispatchQueue.main.asyncAfter(deadline: .now() + 0.7) {
                                    withAnimation (.bouncy(duration: 0.3)){
                                        is14In = true
                                        objeto6YOffset = 0
                                    }
                                    withAnimation(.bouncy(duration: 2)) {
                                        basuraOrganico += 1
                                    }
                                }
                            } else {
                                withAnimation(.spring(duration: 0.5)) {
                                    objeto6XOffset = 0
                                    objeto6YOffset = 0
                                }
                            }
                        }
                )

            Image("15")
                .resizable()
                .scaledToFit()
                .frame(width: 70)
                .position(trash15)
                .offset(x: objeto7XOffset, y: objeto7YOffset)
                .opacity(is15In ? 0 : 1)
                .zIndex(is15In ? 0.4 : 1.0)
                .gesture(
                    DragGesture()
                        .onChanged { value in
                            objeto7XOffset = value.translation.width
                            objeto7YOffset = value.translation.height
                        }
                        .onEnded { _ in
                            
                            let bote1Frame = CGRect(
                                x: ((initialPositionPapel?.x ?? -1000) - 130),
                                y: (((initialPositionPapel?.y ?? -1000) - 155)),
                                width: 260,
                                height: 310
                            )
                            
                            let basuraFrame = CGRect(
                                x: ((trash15.x) + objeto7XOffset) - 30,
                                y: ((trash15.y) + objeto7YOffset) - 45,
                                width: 60,
                                height: 90
                            )
                            
                            is15Colliding = basuraFrame.intersects(bote1Frame)
                            
                            if is15Colliding{
                                withAnimation(.bouncy(duration: 0.6)) {
                                    objeto7XOffset = 0
                                    objeto7YOffset = -210
                                    trash15 = initialPositionPapel ?? CGPoint(x: 0, y: 0)
                                }
                                DispatchQueue.main.asyncAfter(deadline: .now() + 0.7) {
                                    withAnimation (.bouncy(duration: 0.3)){
                                        is15In = true
                                        objeto7YOffset = 0
                                    }
                                    withAnimation(.bouncy(duration: 2)) {
                                        basuraPapel += 1
                                        updatePositionOrganico()
                                        updatePositionVidrio()
                                    }
                                }
                            } else {
                                withAnimation(.spring(duration: 0.5)) {
                                    objeto7XOffset = 0
                                    objeto7YOffset = 0
                                }
                            }
                        }
                )

            Image("18")
                .resizable()
                .scaledToFit()
                .frame(width: 50)
                .position(trash18)
                .offset(x: objeto8XOffset, y: objeto8YOffset)
                .opacity(is18In ? 0 : 1)
                .zIndex(is18In ? 0.4 : 1.0)
                .gesture(
                    DragGesture()
                        .onChanged { value in
                            objeto8XOffset = value.translation.width
                            objeto8YOffset = value.translation.height
                        }
                        .onEnded { _ in
                            
                            let bote1Frame = CGRect(
                                x: ((initialPositionPapel?.x ?? -1000) - 130),
                                y: (((initialPositionPapel?.y ?? -1000) - 155)),
                                width: 260,
                                height: 310
                            )
                            
                            let basuraFrame = CGRect(
                                x: ((trash18.x) + objeto8XOffset) - 30,
                                y: ((trash18.y) + objeto8YOffset) - 35,
                                width: 60,
                                height: 70
                            )
                            
                            is18Colliding = basuraFrame.intersects(bote1Frame)
                            
                            if is18Colliding{
                                withAnimation(.bouncy(duration: 0.6)) {
                                    objeto8XOffset = 0
                                    objeto8YOffset = -210
                                    trash18 = initialPositionPapel ?? CGPoint(x: 0, y: 0)
                                }
                                DispatchQueue.main.asyncAfter(deadline: .now() + 0.7) {
                                    withAnimation (.bouncy(duration: 0.3)){
                                        is18In = true
                                        objeto8YOffset = 0
                                    }
                                    withAnimation(.bouncy(duration: 2)) {
                                        basuraPapel += 1
                                        updatePositionOrganico()
                                        updatePositionVidrio()
                                    }
                                }
                            } else {
                                withAnimation(.spring(duration: 0.5)) {
                                    objeto8XOffset = 0
                                    objeto8YOffset = 0
                                }
                            }
                        }
                )

            Image("19")
                .resizable()
                .scaledToFit()
                .frame(width: 40)
                .position(trash19)
                .offset(x: objeto9XOffset, y: objeto9YOffset)
                .opacity(is19In ? 0 : 1)
                .zIndex(is19In ? 0.4 : 1.0)
                .gesture(
                    DragGesture()
                        .onChanged { value in
                            objeto9XOffset = value.translation.width
                            objeto9YOffset = value.translation.height
                        }
                        .onEnded { _ in
                            
                            let bote1Frame = CGRect(
                                x: ((initialPositionVidrio?.x ?? -1000) - 130),
                                y: (((initialPositionVidrio?.y ?? -1000) - 155)),
                                width: 260,
                                height: 310
                            )
                            
                            let basuraFrame = CGRect(
                                x: ((trash19.x) + objeto9XOffset) - 30,
                                y: ((trash19.y) + objeto9YOffset) - 35,
                                width: 60,
                                height: 70
                            )
                            
                            is19Colliding = basuraFrame.intersects(bote1Frame)
                            
                            if is19Colliding{
                                withAnimation(.bouncy(duration: 0.6)) {
                                    objeto9XOffset = 0
                                    objeto9YOffset = -210
                                    trash19 = initialPositionVidrio ?? CGPoint(x: 0, y: 0)
                                }
                                DispatchQueue.main.asyncAfter(deadline: .now() + 0.7) {
                                    withAnimation (.bouncy(duration: 0.3)){
                                        is19In = true
                                        objeto9YOffset = 0
                                    }
                                    withAnimation(.bouncy(duration: 2)) {
                                        basuraVidrio += 1
                                    }
                                }
                            } else {
                                withAnimation(.spring(duration: 0.5)) {
                                    objeto9XOffset = 0
                                    objeto9YOffset = 0
                                }
                            }
                        }
                )


            Image("27")
                .resizable()
                .scaledToFit()
                .frame(width: 30)
                .position(trash27)
                .offset(x: objeto12XOffset, y: objeto12YOffset)
                .opacity(is27In ? 0 : 1)
                .zIndex(is27In ? 0.4 : 1.0)
                .gesture(
                        DragGesture()
                            .onChanged { value in
                                objeto12XOffset = value.translation.width
                                objeto12YOffset = value.translation.height
                            }
                            .onEnded { _ in
                                
                                let bote1Frame = CGRect(
                                    x: (position2.x - 130),
                                    y: (position2.y - 155),
                                    width: 260,
                                    height: 310
                                )
                                
                                let basuraFrame = CGRect(
                                    x: ((trash27.x) + objeto12XOffset) - 15,
                                    y: ((trash27.y) + objeto12YOffset) - 50,
                                    width: 30,
                                    height: 100
                                )
                                
                                is27Colliding = basuraFrame.intersects(bote1Frame)
                                
                                if is27Colliding{
                                    withAnimation(.bouncy(duration: 0.6)) {
                                        objeto12XOffset = 0
                                        objeto12YOffset = -200
                                        trash27 = position2
                                    }
                                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.7) {
                                        withAnimation (.bouncy(duration: 0.3)){
                                            is27In = true
                                            objeto12YOffset = 0
                                        }
                                        withAnimation(.bouncy(duration: 2)) {
                                            basuraPlastico += 1
                                            updatePositionOrganico()
                                            updatePositionVidrio()
                                        }
                                    }
                                } else {
                                    withAnimation(.spring(duration: 0.5)) {
                                        objeto12XOffset = 0
                                        objeto12YOffset = 0
                                    }
                                }
                            }
                    )
            
            ZStack {
                Image("coinButton")
                    .resizable()
                    .scaledToFit()
                    
                Text(String(appData.coinsAmmount))
                    .font(.custom("RifficFree-Bold", size: 20))
                    .foregroundStyle(.white)
                    .offset(x: 23, y: 1)
            }.frame(width: 115)
                .position(x:appData.UISW * 0.923, y:appData.UISH * 0.075)
            
           
            ZStack {
                Image("bottleButton")
                    .resizable()
                    .scaledToFit()
                    
                Text(String(appData.bottlesAmmount))
                    .font(.custom("RifficFree-Bold", size: 20))
                    .foregroundStyle(.white)
                    .offset(x: 16, y: 8)
            }.frame(width: 103)
                .position(x:appData.UISW * 0.81, y:appData.UISH * 0.068)
            
            Button {
                withAnimation(.easeInOut(duration: 0.2)) {
                    appData.isTuto = true
                }
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                    withAnimation(.bouncy(duration: 0.2)){
                        stepTutorial = 1
                    }
                }
            } label: {
            Image("helpButton")
                .resizable()
                .scaledToFit()
                
            }.frame(width: 125)
                .position(x:appData.UISW * 0.69, y:appData.UISH * 0.077)
            
//            VStack {
//                Text("\(fulfilledConditionsOrganico)")
//                Text("\(initialPositionPapel)")
//                Text("\(initialPositionOrganico)")
//            }.font(.largeTitle.bold())
//                .foregroundStyle(.red)
//                .zIndex(1)
            
            Button {
                withAnimation (.easeInOut(duration: 0.5)){
                    appData.isLevel1Showed = false
                }
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.6) {
                    appData.isLevel1 = false
                }
            } label: {
                Image("backBtn")
                    .resizable()
                    .scaledToFit()
            }.frame(width: 70)
                .position(x: appData.UISW * 0.055, y: appData.UISH * 0.077)
            
            if (basuraMetal == 2 && basuraPapel == 2 && basuraCarton == 2 && basuraVidrio == 2 && basuraOrganico == 2 && basuraPlastico == 2){
                Circle()
                    .foregroundStyle(.clear)
                    .allowsHitTesting(false)
                    .onAppear{
                        withAnimation (.easeInOut(duration: 0.5)){
                            appData.isFinal = true
                        }
                    }
            }
            
            if appData.isTuto {
                Rectangle()
                    .foregroundStyle(.black.opacity(appData.isTuto ? 0.6 : 0))
                    .frame(width: appData.UISW, height: appData.UISH)
                    .zIndex(1.1)
                
                ZStack{
                    Image("step1act1")
                        .resizable()
                        .scaledToFit()
                        .frame(width: appData.UISW * 0.8)
                    
                    Image("face1")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 110)
                        .position(x: appData.UISW * 0.81, y: appData.UISH * 0.31)
                    
                    Button {
                        withAnimation(.bouncy(duration: 0.5)){
                            if stepTutorial == 1 {
                                stepTutorial = 2
                            }
                        }
                    } label: {
                        Image("nextBtn")
                            .resizable()
                            .scaledToFit()
                    }.frame(width: appData.UISW * 0.12)
                        .position(x: appData.UISW * 0.5, y: appData.UISH * 0.69)
                    
                }.offset(y: stepTutorial == 2 || stepTutorial == 3 ? appData.UISH * -1.5 : (stepTutorial == 1 ? 0 : appData.UISH * 1.5))
                .zIndex(1.1)
                
                ZStack{
                    Image("step2act1")
                        .resizable()
                        .scaledToFit()
                        .frame(width: appData.UISW * 0.8)
                        .offset(y: 60)
                    
                    Image("fingerDragCan")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 100)
                        .offset(x: rotateFinger ? 30 : -10, y: rotateFinger ? -30 : 0)
                        .rotationEffect(.degrees(rotateFinger ? 15 : 0), anchor: .center)
                        .animation(.easeInOut(duration: 1).repeatForever(autoreverses: true), value: rotateFinger)
                        .position(x: appData.UISW * 0.18, y: appData.UISH * 0.55)
                        .onAppear {
                            rotateFinger.toggle()
                        }

                    Image("face2")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 100)
                        .position(x: appData.UISW * 0.81, y: appData.UISH * 0.31)
                    
                    Button {
                        withAnimation(.bouncy(duration: 0.5)){
                            if stepTutorial == 2 {
                                stepTutorial = 3
                            }
                        }
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                            withAnimation(.easeInOut(duration: 0.2)){
                                appData.isTuto = false
                            }
                        }
                    } label: {
                        Image("okayBtn")
                            .resizable()
                            .scaledToFit()
                    }.frame(width: appData.UISW * 0.12)
                        .position(x: appData.UISW * 0.5, y: appData.UISH * 0.69)
                    
                }.opacity(stepTutorial == 3 ? 0 : 1)
                .offset(y: stepTutorial == 3 ? appData.UISH * -1.5 : (stepTutorial == 2 ? 0 : appData.UISH * 1.5))
                .zIndex(1.1)
            }
            
            Rectangle()
                .foregroundStyle(.black.opacity(appData.isPopUp ? 0.6 : 0))
                .frame(width: appData.UISW, height: appData.UISH)
                .zIndex(1.1)
            
            Rectangle()
                .foregroundStyle(.black.opacity(appData.isFinal ? 0.6 : 0))
                .frame(width: appData.UISW, height: appData.UISH)
                .zIndex(1.1)
            
            if appData.isFinal {
                ZStack {
                    Image("mensajeFinalAct1")
                        .resizable()
                        .scaledToFit()
                    
                    Button{
                        withAnimation (.easeInOut(duration: 0.5)){
                            appData.isFinal = false
                            appData.bottlesAmmount += 2
                            appData.isLevel1Complete = true
                        }
                    } label: {
                        Image("letsBtn")
                            .resizable()
                            .scaledToFit()
                        
                    }.frame(width: 130)
                        .position(x: appData.UISW * 0.3, y: appData.UISH * 0.86)
                    
                }.frame(width: appData.UISW * 0.6)
                .zIndex(1.1)
            }
            
            if basuraMetal == 2 && isPopMetal == false {
                ZStack {
                    Image("metalPop")
                        .resizable()
                        .scaledToFit()
                        
                    Button{
                        appData.coinsAmmount += 15
                        withAnimation (.easeInOut(duration: 0.5)){
                            appData.isPopUp = false
                            isPopMetal = true
                        }
                    } label :{
                        Image("PButton")
                            .resizable()
                            .scaledToFit()
                        
                    }.frame(width: 170)
                        .position(x:appData.UISW * 0.41, y: appData.UISH * 0.85)
                    
                }.frame(width: appData.UISW * 0.8)
                    .zIndex(2)
                    .onAppear{
                        appData.isPopUp = true
                    }
            }
            
            if basuraPlastico == 2 && isPopPlastico == false {
                ZStack {
                    Image("plasticoPop")
                        .resizable()
                        .scaledToFit()
                        
                    Button{
                        appData.coinsAmmount += 15
                        withAnimation (.easeInOut(duration: 0.5)){
                            appData.isPopUp = false
                            isPopPlastico = true
                        }
                    } label :{
                        Image("PButton")
                            .resizable()
                            .scaledToFit()
                        
                    }.frame(width: 170)
                        .position(x:appData.UISW * 0.41, y: appData.UISH * 0.85)
                    
                }.frame(width: appData.UISW * 0.8)
                    .zIndex(2)
                    .onAppear{
                        appData.isPopUp = true
                    }
            }
            
            if basuraCarton == 2 && isPopCarton == false {
                ZStack {
                    Image("cartonPop")
                        .resizable()
                        .scaledToFit()
                        
                    Button{
                        appData.coinsAmmount += 15
                        withAnimation (.easeInOut(duration: 0.5)){
                            appData.isPopUp = false
                            isPopCarton = true
                        }
                    } label :{
                        Image("PButton")
                            .resizable()
                            .scaledToFit()
                        
                    }.frame(width: 170)
                        .position(x:appData.UISW * 0.41, y: appData.UISH * 0.85)
                    
                }.frame(width: appData.UISW * 0.8)
                    .zIndex(2)
                    .onAppear{
                        appData.isPopUp = true
                    }
            }
            
            if basuraPapel == 2 && isPopPapel == false {
                ZStack {
                    Image("papelPop")
                        .resizable()
                        .scaledToFit()
                        
                    Button{
                        appData.coinsAmmount += 15
                        withAnimation (.easeInOut(duration: 0.5)){
                            appData.isPopUp = false
                            isPopPapel = true
                        }
                    } label :{
                        Image("PButton")
                            .resizable()
                            .scaledToFit()
                        
                    }.frame(width: 170)
                        .position(x:appData.UISW * 0.41, y: appData.UISH * 0.85)
                    
                }.frame(width: appData.UISW * 0.8)
                    .zIndex(2)
                    .onAppear{
                        appData.isPopUp = true
                    }
            }
            
            if basuraOrganico == 2 && isPopOrganico == false {
                ZStack {
                    Image("organicoPop")
                        .resizable()
                        .scaledToFit()
                        
                    Button{
                        appData.coinsAmmount += 15
                        withAnimation (.easeInOut(duration: 0.5)){
                            appData.isPopUp = false
                            isPopOrganico = true
                        }
                    } label :{
                        Image("PButton")
                            .resizable()
                            .scaledToFit()
                        
                    }.frame(width: 170)
                        .position(x:appData.UISW * 0.41, y: appData.UISH * 0.85)
                    
                }.frame(width: appData.UISW * 0.8)
                    .zIndex(2)
                    .onAppear{
                        appData.isPopUp = true
                    }
            }
            
            if basuraVidrio == 2 && isPopVidrio == false {
                ZStack {
                    Image("vidrioPop")
                        .resizable()
                        .scaledToFit()
                        
                    Button{
                        appData.coinsAmmount += 15
                        withAnimation (.easeInOut(duration: 0.5)){
                            appData.isPopUp = false
                            isPopVidrio = true
                        }
                    } label :{
                        Image("PButton")
                            .resizable()
                            .scaledToFit()
                        
                    }.frame(width: 170)
                        .position(x:appData.UISW * 0.41, y: appData.UISH * 0.85)
                    
                }.frame(width: appData.UISW * 0.8)
                    .zIndex(2)
                    .onAppear{
                        appData.isPopUp = true
                    }
            }
            
            CoinPop()
                .position(x: appData.UISW * 0.798, y: appData.UISH * 0.386)
                .opacity(appData.isPopUp ? 1 : 0)
                .zIndex(3)

        }.ignoresSafeArea()
            .onAppear{
                appData.isTuto = true
                stepTutorial = 1
            }
    }
    
    func updatePositionOrganico() {
        if basuraMetal == 2, !fulfilledConditionsOrganico.contains(position1) {
            fulfilledConditionsOrganico.append(position1)
        }
        
        if basuraPlastico == 2, !fulfilledConditionsOrganico.contains(position2) {
            fulfilledConditionsOrganico.append(position2)
        }
        
        if basuraCarton == 2, !fulfilledConditionsOrganico.contains(position3) {
            fulfilledConditionsOrganico.append(position3)
        }
        
        if fulfilledConditionsOrganico.count >= 2, initialPositionOrganico == nil {
            initialPositionOrganico = fulfilledConditionsOrganico[1]
        }
    }
    
    func updatePositionVidrio() {

        if basuraMetal == 2, !fulfilledConditionsVidrio.contains(position1) {
            fulfilledConditionsVidrio.append(position1)
        }
        
        if basuraPlastico == 2, !fulfilledConditionsVidrio.contains(position2) {
            fulfilledConditionsVidrio.append(position2)
        }
        
        if basuraCarton == 2, !fulfilledConditionsVidrio.contains(position3) {
            fulfilledConditionsVidrio.append(position3)
        }
        
        if fulfilledConditionsVidrio.count >= 3, initialPositionVidrio == nil {
            initialPositionVidrio = fulfilledConditionsVidrio[2]
        }
    }

}

#Preview {
    Act_1()
        .environmentObject(AppData())
}
