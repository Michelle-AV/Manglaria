import SwiftUI

struct Act_3: View {

    @EnvironmentObject var appData: AppData

    @State private var tourtleMovement: Bool = false
    @State private var cocoMovement: Bool = false
    
    @State private var fishMovement: Bool = false
    @State private var offsetXFish1: CGFloat = .zero
    @State private var offsetXFish2: CGFloat = .zero
    @State private var rotateFish1: Bool = false
    @State private var rotateFish2: Bool = false
    
    @State private var coinMovement: Bool = false
    
    @State private var offsetXPinza: CGFloat = .zero
    @State private var offsetYPinza: CGFloat = .zero
    
    @State private var isPinzasCollidingTourtle: Bool = false

    @State private var offsetXEsponja: CGFloat = .zero
    @State private var offsetYEsponja: CGFloat = .zero
    
    @State private var isEsponjaCollidingGarza: Bool = false
    @State private var isEsponjaCollidingCoco: Bool = false
    
    @State private var offsetXTijera: CGFloat = .zero
    @State private var offsetYTijera: CGFloat = .zero
    
    @State private var isTijerasCollidingMono: Bool = false
    @State private var isTijerasCollidingTourtle: Bool = false
    
    @State private var isCT1Clean: Bool = false
    @State private var isCT2Clean: Bool = false
    @State private var isMonoClean: Bool = false
    @State private var isGarzaClean: Bool = false
    @State private var isCocoClean: Bool = false
    
    @State private var isAllClean: Bool = false
    
    @State private var isRotated = false
    
    //MARK: Var for PopUps
    
    @State private var isMonoPU: Bool = false
    @State private var isGarzaPU: Bool = false
    @State private var isTurtlePU: Bool = false
    @State private var isCocoPU: Bool = false
    
    //MARK: Var for Animations - Animals
    
    @State private var offsetXTurtle: CGFloat = .zero
    @State private var rotateTurtle: Bool = false
    
    @State private var offsetXCoco: CGFloat = .zero
    @State private var rotateCoco: Bool = false
    
    //MARK: Dialogues
    
    @State private var isDialogueMono: Bool = true
    @State private var isDialogueGarza: Bool = false
    @State private var isDialogueTurtle: Bool = false
    @State private var isDialogueCoco: Bool = false
    
    //MARK: Tuto vars
    
    @State private var stepTutorial: Int = 0
    @State private var rotateFinger: Bool = false

    
    var body: some View {
        ZStack{
            
            Rectangle()
                .foregroundStyle(Color.Sky)
                .onAppear{
                    withAnimation(.easeInOut(duration: 0.1)) {
                        appData.isTuto = true
                        stepTutorial = 1
                    }
                }
            
            Sun()
                .position(x: appData.UISW * 0.89, y: appData.UISH * 0.16)
            
            Image("F2A3")
                .resizable()
                .scaledToFill()
                .frame(width: appData.UISW * 1.01)
                .position(x: appData.UISW * 0.5, y: appData.UISH * 0.5)
            
            Image(isCT2Clean ? "CTL2" : "CTS2")
                .resizable()
                .scaledToFit()
                .frame(width: 160)
                .scaleEffect(x: !isAllClean ? 1 :rotateTurtle ? -1 : 1, y: 1)
                .position(x:isCT2Clean ? appData.UISW * 0.65 : appData.UISW * 0.63, y: isCT2Clean ? appData.UISH * 0.9 : appData.UISH * 0.89)
                .offset(x: !isAllClean ? 0 : offsetXTurtle, y: tourtleMovement ? -5 : 5)
                .animation(.easeInOut(duration: 2).repeatForever(autoreverses: true), value: tourtleMovement)
                .onAppear {
                    tourtleMovement.toggle()
                }
                .zIndex(0.4)
                .onTapGesture {
                    withAnimation(.spring(duration: 0.2)) {
                        appData.isDialog = true
                    }
                    withAnimation (.easeInOut(duration: 0.5)){
                        isDialogueTurtle = true
                    }
                }
            
            Image("CC1")
                .resizable()
                .scaledToFit()
                .frame(width: 300)
                .scaleEffect(x: !isAllClean ? 1 :rotateCoco ? -1 : 1, y: 1)
                .position(x: appData.UISW * 0.17, y: appData.UISH * 0.82)
                .offset(x: !isAllClean ? 0 : offsetXCoco, y: cocoMovement ? -0 : -5)
                .animation(.easeInOut(duration: 2).repeatForever(autoreverses: true), value: cocoMovement)
                .onAppear {
                    cocoMovement.toggle()
                }
                .zIndex(0.3)
                .onTapGesture {
                    withAnimation(.spring(duration: 0.2)) {
                        appData.isDialog = true
                    }
                    withAnimation (.easeInOut(duration: 0.5)){
                        isDialogueCoco = true
                    }
                }
            
            Image(isMonoClean ? "M2" : "M1")
                .resizable()
                .scaledToFit()
                .frame(width: 150)
                .position(x: appData.UISW * 0.26, y:isMonoClean ? appData.UISH * 0.16 : appData.UISH * 0.1)
                .onTapGesture {
                    withAnimation(.spring(duration: 0.2)) {
                        appData.isDialog = true
                    }
                    withAnimation (.easeInOut(duration: 0.5)){
                        isDialogueMono = true
                    }
                }
            
            Image(isAllClean ? "pezHappy":"pezSad")
                .resizable()
                .scaledToFit()
                .frame(width: 60)
                .offset(x: !isAllClean ? 0 : offsetXFish1, y: !fishMovement ? 0 : -15)
                .position(x: appData.UISW * 0.2, y: appData.UISH * 0.89)
                .zIndex(0.3)
                .animation(.easeInOut(duration: 2).repeatForever(autoreverses: true), value: fishMovement)
                .onAppear {
                    fishMovement.toggle()
                }
            
            Image(isAllClean ? "pezHappy":"pezSad")
                .resizable()
                .scaledToFit()
                .frame(width: 60)
                .offset(x: !isAllClean ? 0 : offsetXFish2, y: fishMovement ? 0 : -15)
                .scaleEffect(x: -1, y: 1)
                .position(x: appData.UISW * 0.9, y: appData.UISH * 0.8)
                .zIndex(0.2)
                .animation(.easeInOut(duration: 2).repeatForever(autoreverses: true), value: fishMovement)

            Rectangle()
                .foregroundStyle(isAllClean ? Color.AL.opacity(0.62) : Color.AS.opacity(0.62))
                .frame(width: appData.UISW, height: appData.UISH * 0.33)
                .position(x: appData.UISW * 0.5, y: appData.UISH * 0.856)
                .zIndex(0.5)
            
            Clouds()
            
            Image(isAllClean ? "AL1" : "AS1")
                .resizable()
                .scaledToFit()
                .frame(width: 200)
                .position(x: appData.UISW * 0.49, y: appData.UISH * 0.68)
                .zIndex(0.6)
            
            Image(isAllClean ? "AL2" : "AS2")
                .resizable()
                .scaledToFit()
                .frame(width: 70)
                .position(x: appData.UISW * 0.599, y: appData.UISH * 0.66)
                .zIndex(0.6)
            
            Image(isAllClean ? "GaL1" : (isGarzaClean ? "GaL" : "GaSu"))
                .resizable()
                .scaledToFit()
                .frame(width: 260)
                .position(x: appData.UISW * 0.756, y: appData.UISH * 0.636)
                .zIndex(0.6)
                .onTapGesture {
                    withAnimation(.spring(duration: 0.2)) {
                        appData.isDialog = true
                    }
                    withAnimation (.easeInOut(duration: 0.5)){
                        isDialogueGarza = true
                    }
                }
            
            if isAllClean {
                Image("ala")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 38)
                    .rotationEffect(.degrees(isRotated ? -12 : 0))
                    .position(x: appData.UISW * 0.8, y: appData.UISH * 0.57)
                    .animation(.easeInOut(duration: 0.5).repeatForever(autoreverses: true), value: isRotated)
                    .onAppear {
                        isRotated.toggle()
                        Timer.scheduledTimer(withTimeInterval: 0.000001, repeats: true) { _ in
                            DispatchQueue.main.async {
                                
                                if offsetXCoco < 650 && rotateCoco == false{
                                    offsetXCoco += 0.01
                                } else if offsetXCoco > 100 {
                                    rotateCoco = true
                                    offsetXCoco -= 0.01
                                    
                                } else {
                                    rotateCoco = false
                                }
                                
                                if offsetXTurtle > -560 && rotateTurtle == false{
                                    offsetXTurtle -= 0.015
                                } else if offsetXTurtle < 250 {
                                    rotateTurtle = true
                                    offsetXTurtle += 0.015
                                } else {
                                    rotateTurtle = false
                                }
                            }
                        }
                    }
                    .zIndex(0.7)
            }
            
            Image(isAllClean ? "CTL1" : (isCT1Clean ? "CTSL" : "CTS1"))
                .resizable()
                .scaledToFit()
                .frame(width: 120)
                .scaleEffect(x: !isAllClean ? 1 : rotateTurtle ? -1 : 1, y: 1)
                .position(x: appData.UISW * 0.58, y: isCT1Clean ? appData.UISH * 0.87 : appData.UISH * 0.86)
                .offset(x: !isAllClean ? 0 : rotateTurtle ? 160 : 0)
                .offset(x: !isAllClean ? 0 : offsetXTurtle, y: tourtleMovement ? -5 : 5)
                .animation(.easeInOut(duration: 2).repeatForever(autoreverses: true), value: tourtleMovement)
                .zIndex(0.7)
                .onTapGesture {
                    withAnimation(.spring(duration: 0.2)) {
                        appData.isDialog = true
                    }
                    withAnimation (.easeInOut(duration: 0.5)){
                        isDialogueTurtle = true
                    }
                }
            
            
            Image(isAllClean ? "CCL" : (isCocoClean ? "CCSL" : "CC2"))
                .resizable()
                .scaledToFit()
                .frame(width: 370)
                .scaleEffect(x: !isAllClean ? 1 : rotateCoco ? -1 : 1, y: 1)
                .offset(x:!isAllClean ? 0 : rotateCoco ? -190 : 0)
                .offset(x: !isAllClean ? 0 : offsetXCoco, y: cocoMovement ? -0 : -5)
                .position(x: appData.UISW * 0.25, y: appData.UISH * 0.78)
                .animation(.easeInOut(duration: 2).repeatForever(autoreverses: true), value: cocoMovement)
                .zIndex(0.6)
                .onTapGesture {
                    withAnimation(.spring(duration: 0.2)) {
                        appData.isDialog = true
                    }
                    withAnimation (.easeInOut(duration: 0.5)){
                        isDialogueCoco = true
                    }
                }
            
            //            Rectangle()
            //                .foregroundStyle(.cyan)
            //                .frame(width: 65, height: 60)
            //                .position(x: (appData.UISW * 0.078) + offsetXEsponja,
            //                          y: (appData.UISH * 0.266) + offsetYEsponja)
            
            //            Rectangle()
            //                .foregroundStyle(.black)
            //                .frame(width: 140, height: 60)
            //                .position(x: appData.UISW * 0.31, y: appData.UISH * 0.75)
            
            ZStack{
                Circle()
                    .frame(width: 100)
                    .foregroundStyle(Color.AO)
                
                Circle()
                    .frame(width: 89)
                    .foregroundStyle(Color.Blue)
                
                Image("Pinzas")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 27)
                    .offset(x: offsetXPinza, y: offsetYPinza)
                    .gesture(
                        DragGesture()
                            .onChanged { gesture in
                                offsetXPinza = gesture.translation.width
                                offsetYPinza = gesture.translation.height
                                
                                let pinzasFrame = CGRect(
                                    x: (appData.UISW * 0.078) + offsetXPinza,
                                    y: (appData.UISH * 0.348) + offsetYPinza,
                                    width: 15,
                                    height: 27
                                )
                                
                                let cts1Frame = CGRect(
                                    x: appData.UISW * 0.53,
                                    y: appData.UISH * 0.79,
                                    width: 80,
                                    height: 100
                                )
                                
                                isPinzasCollidingTourtle = pinzasFrame.intersects(cts1Frame)
                            }
                            .onEnded { _ in
                                if isPinzasCollidingTourtle == true && isCT1Clean == false{
                                    if isCT2Clean {
                                        withAnimation(.easeInOut(duration: 0.2)) {
                                            appData.isPopUp = true
                                        }
                                        withAnimation(.bouncy(duration: 0.6)) {
                                            isTurtlePU = true
                                        }
                                        coinMovement.toggle()
                                    }
                                    isCT1Clean = true
                                    isPinzasCollidingTourtle = false
                                } else {
                                    isPinzasCollidingTourtle = false
                                }
                                withAnimation(.spring()) {
                                    offsetXPinza = .zero
                                    offsetYPinza = .zero
                                }
                                if isCocoClean && isMonoClean && isGarzaClean && isCT1Clean && isCT2Clean {
                                    withAnimation(.easeInOut(duration: 0.25)) {
                                        isAllClean = true
                                    }
                                }
                            }
                    )
                
            }.position(x: appData.UISW * 0.078, y: appData.UISH * 0.348)
                .zIndex(0.7)
            
            ZStack{
                Circle()
                    .frame(width: 100)
                    .foregroundStyle(Color.AO)
                
                Circle()
                    .frame(width: 89)
                    .foregroundStyle(Color.Blue)
                
                Image("Esponja")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 65)
                    .offset(x: offsetXEsponja, y: offsetYEsponja)
                    .gesture(
                        DragGesture()
                            .onChanged { gesture in
                                offsetXEsponja = gesture.translation.width
                                offsetYEsponja = gesture.translation.height
                                
                                let spongeFrame = CGRect(
                                    x: (appData.UISW * 0.078) + offsetXEsponja,
                                    y: (appData.UISH * 0.5) + offsetYEsponja,
                                    width: 65, height: 60
                                )
                                
                                let garzaFrame = CGRect(
                                    x: appData.UISW * 0.78, y: appData.UISH * 0.59,
                                    width: 90, height: 140
                                )
                                
                                let cocoFrame = CGRect(
                                    x: appData.UISW * 0.31, y: appData.UISH * 0.75,
                                    width: 140, height: 60
                                )
                                
                                isEsponjaCollidingGarza = spongeFrame.intersects(garzaFrame)
                                isEsponjaCollidingCoco = spongeFrame.intersects(cocoFrame)
                            }
                            .onEnded { _ in
                                if isEsponjaCollidingGarza == true && isGarzaClean == false{
                                    withAnimation(.easeInOut(duration: 0.2)) {
                                        appData.isPopUp = true
                                    }
                                    withAnimation(.bouncy(duration: 0.6)) {
                                        isGarzaPU = true
                                    }
                                    coinMovement.toggle()
                                    isGarzaClean = true
                                    isEsponjaCollidingGarza = false
                                }else if isEsponjaCollidingCoco == true && isCocoClean == false {
                                    withAnimation(.easeInOut(duration: 0.2)) {
                                        appData.isPopUp = true
                                    }
                                    withAnimation(.bouncy(duration: 0.6)) {
                                        isCocoPU = true
                                    }
                                    coinMovement.toggle()
                                    isCocoClean = true
                                    isEsponjaCollidingCoco = false
                                } else {                                    isEsponjaCollidingGarza = false
                                    isEsponjaCollidingCoco = false
                                    
                                }
                                withAnimation(.spring()) {
                                    offsetXEsponja = .zero
                                    offsetYEsponja = .zero
                                }
                                if isCocoClean && isMonoClean && isGarzaClean && isCT1Clean && isCT2Clean {
                                    withAnimation(.easeInOut(duration: 0.25)) {
                                        isAllClean = true
                                    }
                                }
                            }
                    )
                
            }.position(x: appData.UISW * 0.078, y: appData.UISH * 0.5)
                .zIndex(0.7)
            
            ZStack{
                Circle()
                    .frame(width: 100)
                    .foregroundStyle(Color.AO)
                
                Circle()
                    .frame(width: 89)
                    .foregroundStyle(Color.Blue)
                
                Image("Tijeras")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 65)
                    .offset(x: offsetXTijera, y: offsetYTijera)
                    .gesture(
                        DragGesture()
                            .onChanged { gesture in
                                offsetXTijera = gesture.translation.width
                                offsetYTijera = gesture.translation.height
                                
                                let tijerasFrame = CGRect(
                                    x: (appData.UISW * 0.078) + offsetXTijera,
                                    y: (appData.UISH * 0.65) + offsetYTijera,
                                    width: 70,
                                    height: 70
                                )
                                
                                let monoFrame = CGRect(
                                    x: appData.UISW * 0.255, y: appData.UISH * 0.1,
                                    width: 110,
                                    height: 140
                                )
                                
                                let turtleFrame = CGRect(
                                    x: appData.UISW * 0.635, y: appData.UISH * 0.82,
                                    width: 150, height: 100
                                )
                                
                                isTijerasCollidingMono = tijerasFrame.intersects(monoFrame)
                                isTijerasCollidingTourtle = tijerasFrame.intersects(turtleFrame)
                            }
                            .onEnded { _ in
                                if isTijerasCollidingMono == true && isMonoClean == false{
                                    withAnimation(.easeInOut(duration: 0.2)) {
                                        appData.isPopUp = true
                                    }
                                    withAnimation(.bouncy(duration: 0.6)) {
                                        isMonoPU = true
                                    }
                                    coinMovement.toggle()
                                    isMonoClean = true
                                    isTijerasCollidingMono = false
                                }else if isTijerasCollidingTourtle == true && isCT2Clean == false{
                                    if isCT1Clean {
                                        withAnimation(.easeInOut(duration: 0.2)) {
                                            appData.isPopUp = true
                                        }
                                        withAnimation(.bouncy(duration: 0.6)) {
                                            isTurtlePU = true
                                        }
                                        coinMovement.toggle()
                                    }
                                    isCT2Clean = true
                                    isTijerasCollidingTourtle = false
                                } else {
                                    isTijerasCollidingMono = false
                                    isTijerasCollidingTourtle = false
                                }
                                withAnimation(.spring()) {
                                    offsetXTijera = .zero
                                    offsetYTijera = .zero
                                }
                                if isCocoClean && isMonoClean && isGarzaClean && isCT1Clean && isCT2Clean {
                                    withAnimation(.easeInOut(duration: 0.25)) {
                                        isAllClean = true
                                    }
                                }
                            }
                    )
                
            }.position(x: appData.UISW * 0.078, y: appData.UISH * 0.65)
                .zIndex(0.7)
            
            ZStack {
                Image("coinButton")
                    .resizable()
                    .scaledToFit()
                    
                Text(String(appData.coinsAmmount))
                    .font(.custom("RifficFree-Bold", size: 20))
                    .foregroundStyle(.white)
                    .offset(x: 23, y: 1)
            }.frame(width: 115)
                .position(x:appData.UISW * 0.923, y:appData.UISH * 0.075)
            
           
            ZStack {
                Image("bottleButton")
                    .resizable()
                    .scaledToFit()
                    
                Text(String(appData.bottlesAmmount))
                    .font(.custom("RifficFree-Bold", size: 20))
                    .foregroundStyle(.white)
                    .offset(x: 16, y: 8)
            }.frame(width: 103)
                .position(x:appData.UISW * 0.81, y:appData.UISH * 0.068)
            
            Button {
                withAnimation(.easeInOut(duration: 0.2)) {
                    appData.isTuto = true
                }
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                    withAnimation(.bouncy(duration: 0.2)){
                        stepTutorial = 1
                    }
                }
            } label: {
            Image("helpButton")
                .resizable()
                .scaledToFit()
                
            }.frame(width: 125)
                .position(x:appData.UISW * 0.69, y:appData.UISH * 0.077)
                .zIndex(0.8)
            
            Button {
                withAnimation (.easeInOut(duration: 0.5)){
                    appData.isLevel3Showed = false
                }
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.6) {
                    appData.isLevel3 = false
                }
            } label: {
                Image("backBtn")
                    .resizable()
                    .scaledToFit()
            }.frame(width: 70)
                .position(x: appData.UISW * 0.055, y: appData.UISH * 0.077)
            
            Image("RA3")
                .resizable()
                .scaledToFill()
                .frame(width: appData.UISW * 1)
                .position(x: appData.UISW * 0.5, y: appData.UISH * 0.5)
                .opacity(0.0)
            
//            Text("\(offsetXCoco)Hola")
//                .font(.custom("RifficFree-Bold", size: 50))
//                .foregroundStyle(.white)
            
            if appData.isDialog {
                Image("dialogoMono")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 520)
                    .position(x: appData.UISW * 0.36, y: appData.UISH * 0.25)
                    .opacity(isDialogueMono ? 1 : 0)
                    .zIndex(0.8)
                    .onAppear{
                        DispatchQueue.main.asyncAfter(deadline: .now() + 5) {
                            withAnimation(.spring(duration: 0.4)) {
                                appData.isDialog = false
                            }
                            withAnimation (.easeInOut(duration: 0.2)){
                                isDialogueMono = false
                            }
                        }
                    }
                
                Image("dialogoGarza")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 480)
                    .opacity(isDialogueGarza ? 1 : 0)
                    .position(x: appData.UISW * 0.67, y: appData.UISH * 0.42)
                    .zIndex(0.8)
                    .onAppear{
                        DispatchQueue.main.asyncAfter(deadline: .now() + 5) {
                            withAnimation(.spring(duration: 0.4)) {
                                appData.isDialog = false
                            }
                            withAnimation (.easeInOut(duration: 0.2)){
                                isDialogueGarza = false
                            }
                        }
                    }
                
                Image("dialogoCoco")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 520)
                    .opacity(isDialogueCoco ? 1 : 0)
                    .position(x: appData.UISW * 0.34, y: appData.UISH * 0.65)
                    .offset(x: offsetXCoco)
                    .offset(x: !rotateCoco ? 0 : -300)
                    .zIndex(0.8)
                    .onAppear{
                        DispatchQueue.main.asyncAfter(deadline: .now() + 5) {
                            withAnimation(.spring(duration: 0.4)) {
                                appData.isDialog = false
                            }
                            withAnimation (.easeInOut(duration: 0.2)){
                                isDialogueCoco = false
                            }
                        }
                    }
                
                Image("dialogoTortu")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 480)
                    .opacity(isDialogueTurtle ? 1 : 0)
                    .position(x: appData.UISW * 0.3, y: appData.UISH * 0.85)
                    .offset(x: offsetXTurtle)
                    .offset(x: !rotateTurtle ? 0 : 200)
                    .zIndex(0.8)
                    .onAppear{
                        DispatchQueue.main.asyncAfter(deadline: .now() + 5) {
                            withAnimation(.spring(duration: 0.4)) {
                                appData.isDialog = false
                            }
                            withAnimation (.easeInOut(duration: 0.2)){
                                isDialogueTurtle = false
                            }
                        }
                    }

            }
            
            if appData.isPopUp {
                Rectangle()
                    .foregroundStyle(.black.opacity(appData.isPopUp ? 0.6 : 0))
                    .frame(width: appData.UISW, height: appData.UISH)
                    .zIndex(1.0)
                
                ZStack{
                    Image("mono-pop")
                        .resizable()
                        .scaledToFit()
                        .frame(width: appData.UISW * 0.8, height: appData.UISH * 0.8)
                        .opacity(1)
                    
                    Button{
                        appData.coinsAmmount += 10
                        withAnimation(.easeInOut(duration: 0.2)) {
                            DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
                                appData.isPopUp = false
                            }
                            isMonoPU = false
                        }
                        if isCocoClean && isMonoClean && isGarzaClean && isCT1Clean && isCT2Clean {
                            withAnimation(.easeInOut(duration: 0.25)) {
                                appData.isFinal = true
                            }
                        }
                    } label: {
                        Image("PButton")
                            .resizable()
                            .scaledToFit()
                            .frame(width: appData.UISW * 0.15)
                    }.position(x: appData.UISW * 0.5, y: appData.UISH * 0.83)
                    
                    Rectangle()
                        .foregroundStyle(Color.Rose)
                        .frame(width: appData.UISW * 0.06, height: appData.UISH * 0.02)
                        .position(x: appData.UISW * 0.786, y: appData.UISH * 0.43)
                    
                    CoinPop()
                        .position(x: appData.UISW * 0.787, y: appData.UISH * 0.37)
                    
                    Button {
                        
                    }label: {
                        ZStack{
                            RoundedRectangle(cornerRadius: 10)
                                .foregroundStyle(Color.Yellow)
                                .frame(width: appData.UISW * 0.115, height: appData.UISH * 0.04)
                            
                            Text("Get all!")
                                .font(.custom("RifficFree-Bold", size: 18))
                                .foregroundStyle(Color.GoldenL)
                        }
                    }.position(x: appData.UISW * 0.785, y: appData.UISH * 0.53)

                }.offset(y:!isMonoPU ? -appData.UISH * 1.5 : 0)
                    .opacity(!isMonoPU ? 0 : 1)
                    .zIndex(1.0)
                
                ZStack{
                    Image("garza-pop")
                        .resizable()
                        .scaledToFit()
                        .frame(width: appData.UISW * 0.8, height: appData.UISH * 0.8)
                        .opacity(1)
                    
                    Button{
                        appData.coinsAmmount += 20
                        withAnimation(.easeInOut(duration: 0.2)) {
                            DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
                                    appData.isPopUp = false
                            }
                            isGarzaPU = false
                        }
                        if isCocoClean && isMonoClean && isGarzaClean && isCT1Clean && isCT2Clean {
                            withAnimation(.easeInOut(duration: 0.25)) {
                                appData.isFinal = true
                            }
                        }
                    } label: {
                        Image("PButton")
                            .resizable()
                            .scaledToFit()
                            .frame(width: appData.UISW * 0.15)
                    }.position(x: appData.UISW * 0.5, y: appData.UISH * 0.83)
                    
                    Rectangle()
                        .foregroundStyle(Color.Rose)
                        .frame(width: appData.UISW * 0.06, height: appData.UISH * 0.02)
                        .position(x: appData.UISW * 0.786, y: appData.UISH * 0.43)
                    
                    CoinPop()
                        .position(x: appData.UISW * 0.793, y: appData.UISH * 0.422)
                    
                    Button {
                        
                    }label: {
                        ZStack{
                            RoundedRectangle(cornerRadius: 10)
                                .foregroundStyle(Color.Yellow)
                                .frame(width: appData.UISW * 0.115, height: appData.UISH * 0.04)
                            
                            Text("Get all!")
                                .font(.custom("RifficFree-Bold", size: 18))
                                .foregroundStyle(Color.GoldenL)
                        }
                    }.position(x: appData.UISW * 0.7905, y: appData.UISH * 0.58)

                }.offset(y:!isGarzaPU ? -appData.UISH * 1.5 : 0)
                    .opacity(!isGarzaPU ? 0 : 1)
                    .zIndex(1.0)
                
                ZStack{
                    Image("turtle-pop")
                        .resizable()
                        .scaledToFit()
                        .frame(width: appData.UISW * 0.8, height: appData.UISH * 0.8)
                        .opacity(1)
                    
                    Button{
                        appData.coinsAmmount += 25
                        withAnimation(.easeInOut(duration: 0.2)) {
                            DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
                                    appData.isPopUp = false
                            }
                            isTurtlePU = false
                        }
                        if isCocoClean && isMonoClean && isGarzaClean && isCT1Clean && isCT2Clean {
                            withAnimation(.easeInOut(duration: 0.25)) {
                                appData.isFinal = true
                            }
                        }
                    } label: {
                        Image("PButton")
                            .resizable()
                            .scaledToFit()
                            .frame(width: appData.UISW * 0.15)
                    }.position(x: appData.UISW * 0.5, y: appData.UISH * 0.83)
                    
                    Rectangle()
                        .foregroundStyle(Color.Rose)
                        .frame(width: appData.UISW * 0.06, height: appData.UISH * 0.02)
                        .position(x: appData.UISW * 0.79, y: appData.UISH * 0.445)
                    
                    CoinPop()
                        .position(x: appData.UISW * 0.793, y: appData.UISH * 0.385)

                    Button {
                        
                    }label: {
                        ZStack{
                            RoundedRectangle(cornerRadius: 10)
                                .foregroundStyle(Color.Yellow)
                                .frame(width: appData.UISW * 0.115, height: appData.UISH * 0.04)
                            
                            Text("Get all!")
                                .font(.custom("RifficFree-Bold", size: 18))
                                .foregroundStyle(Color.GoldenL)
                        }
                    }.position(x: appData.UISW * 0.7915, y: appData.UISH * 0.55)

                }.offset(y:!isTurtlePU ? -appData.UISH * 1.5 : 0)
                    .opacity(!isTurtlePU ? 0 : 1)
                    .zIndex(1.0)
                
                ZStack{
                    Image("coco-pop")
                        .resizable()
                        .scaledToFit()
                        .frame(width: appData.UISW * 0.8, height: appData.UISH * 0.8)
                        .opacity(1)
                    
                    Button{
                        appData.coinsAmmount += 15
                        withAnimation(.easeInOut(duration: 0.2)) {
                            DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
                                    appData.isPopUp = false
                            }
                            isCocoPU = false
                        }
                        if isCocoClean && isMonoClean && isGarzaClean && isCT1Clean && isCT2Clean {
                            withAnimation(.easeInOut(duration: 0.25)) {
                                appData.isFinal = true
                            }
                        }
                    } label: {
                        Image("PButton")
                            .resizable()
                            .scaledToFit()
                            .frame(width: appData.UISW * 0.15)
                    }.position(x: appData.UISW * 0.5, y: appData.UISH * 0.83)
                    
                    Rectangle()
                        .foregroundStyle(Color.Rose)
                        .frame(width: appData.UISW * 0.06, height: appData.UISH * 0.02)
                        .position(x: appData.UISW * 0.79, y: appData.UISH * 0.445)
                    
                    CoinPop()
                        .position(x: appData.UISW * 0.787, y: appData.UISH * 0.39)

                    Button {
                        
                    }label: {
                        ZStack{
                            RoundedRectangle(cornerRadius: 10)
                                .foregroundStyle(Color.Yellow)
                                .frame(width: appData.UISW * 0.115, height: appData.UISH * 0.04)
                            
                            Text("Get all!")
                                .font(.custom("RifficFree-Bold", size: 18))
                                .foregroundStyle(Color.GoldenL)
                        }
                    }.position(x: appData.UISW * 0.7857, y: appData.UISH * 0.55)

                }.offset(y:!isCocoPU ? -appData.UISH * 1.5 : 0)
                    .opacity(!isCocoPU ? 0 : 1)
                    .zIndex(1.0)
            }
            
            if appData.isTuto {
                Rectangle()
                    .foregroundStyle(.black.opacity(appData.isTuto ? 0.6 : 0))
                    .frame(width: appData.UISW, height: appData.UISH)
                    .zIndex(1.0)
                
                ZStack{
                    Image("step1act3")
                        .resizable()
                        .scaledToFit()
                        .frame(width: appData.UISW * 0.8)
                    
                    Image("face2")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 100)
                        .position(x: appData.UISW * 0.81, y: appData.UISH * 0.31)
                    
                    Button {
                        withAnimation(.bouncy(duration: 0.5)){
                            if stepTutorial == 1 {
                                stepTutorial = 2
                            }
                        }
                    } label: {
                        Image("nextBtn")
                            .resizable()
                            .scaledToFit()
                    }.frame(width: appData.UISW * 0.12)
                        .position(x: appData.UISW * 0.5, y: appData.UISH * 0.69)
                    
                }.offset(y: stepTutorial == 2 || stepTutorial == 3 ? appData.UISH * -1.5 : (stepTutorial == 1 ? 0 : appData.UISH * 1.5))
                .zIndex(1.1)
                
                ZStack{
                    Image("step2act3")
                        .resizable()
                        .scaledToFit()
                        .frame(width: appData.UISW * 0.8)
                    
                    Image("face1")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 110)
                        .position(x: appData.UISW * 0.8, y: appData.UISH * 0.31)
                    
                    Image("fingerSponge")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 100)
                        .offset(x: rotateFinger ? -10 : 0, y: rotateFinger ? -30 : 0)
                        .rotationEffect(.degrees(rotateFinger ? 15 : 0), anchor: .center)
                        .animation(.easeInOut(duration: 1).repeatForever(autoreverses: true), value: rotateFinger)
                        .position(x: appData.UISW * 0.18, y: appData.UISH * 0.51)
                        .onAppear {
                            rotateFinger.toggle()
                        }

                    Button {
                        withAnimation(.bouncy(duration: 0.5)){
                            if stepTutorial == 2 {
                                stepTutorial = 3
                            }
                        }
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                            withAnimation(.easeInOut(duration: 0.2)){
                                appData.isTuto = false
                            }
                        }
                    } label: {
                        Image("okayBtn")
                            .resizable()
                            .scaledToFit()
                    }.frame(width: appData.UISW * 0.12)
                        .position(x: appData.UISW * 0.5, y: appData.UISH * 0.69)
                    
                }.opacity(stepTutorial == 3 ? 0 : 1)
                .offset(y: stepTutorial == 3 ? appData.UISH * -1.5 : (stepTutorial == 2 ? 0 : appData.UISH * 1.5))
                .zIndex(1.1)

            }
            
            Rectangle()
                .foregroundStyle(.black.opacity(appData.isFinal ? 0.6 : 0))
                .frame(width: appData.UISW, height: appData.UISH)
                .zIndex(1.1)
            
            if appData.isFinal {
                ZStack {
                    Image("mensajeFinalAct3")
                        .resizable()
                        .scaledToFit()
                    
                    Button{
                        withAnimation (.easeInOut(duration: 0.5)){
                            appData.isFinal = false
                            appData.bottlesAmmount += 2
                            appData.isLevel3Complete = true
                        }
                    } label: {
                        Image("letsBtn")
                            .resizable()
                            .scaledToFit()
                        
                    }.frame(width: 130)
                        .position(x: appData.UISW * 0.3, y: appData.UISH * 0.86)
                    
                }.frame(width: appData.UISW * 0.6)
                .zIndex(1.1)
            }
            
        }.ignoresSafeArea()
        .frame(width: appData.UISW, height: appData.UISH)
    }
}

#Preview {
    Act_3()
        .environmentObject(AppData())
}
