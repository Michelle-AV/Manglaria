import SwiftUI

@main
struct MyApp: App {
    
    @StateObject private var appData = AppData()

    init() {
        registerFont(fontName: "RifficFree-Bold", fontExtension: "ttf")
    }
    
    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(appData)
        }
    }
    
    func registerFont(fontName: String, fontExtension: String) {
        guard let fontURL = Bundle.main.url(forResource: fontName, withExtension: fontExtension),
              let fontDataProvider = CGDataProvider(url: fontURL as CFURL),
              let font = CGFont(fontDataProvider) else {
            print("No se pudo registrar la fuente \(fontName)")
            return
        }
        
        var error: Unmanaged<CFError>?
        if !CTFontManagerRegisterGraphicsFont(font, &error) {
            print("Error al registrar la fuente: \(error.debugDescription)")
        }
    }
}
