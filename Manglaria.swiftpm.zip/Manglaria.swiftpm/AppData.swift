import SwiftUI
import Combine

@MainActor
class AppData: ObservableObject {
    @Published var UISW: CGFloat = UIScreen.main.bounds.width
    @Published var UISH: CGFloat = UIScreen.main.bounds.height
    
    @Published var isPopUp: Bool = false
    @Published var isDialog: Bool = false
    
    @Published var isTuto: Bool = false
    @Published var isFinal: Bool = false
    
    @Published var coinsAmmount: Int = 0
    @Published var bottlesAmmount: Int = 0
    
    @Published var activitiesCompleted: Int = 0
    
    @Published var isLevel1: Bool = false
    @Published var isLevel2: Bool = false
    @Published var isLevel3: Bool = false
    
    @Published var isLevel1Showed: Bool = false
    @Published var isLevel2Showed: Bool = false
    @Published var isLevel3Showed: Bool = false
    
    @Published var isLevel1Complete: Bool = false
    @Published var isLevel2Complete: Bool = false
    @Published var isLevel3Complete: Bool = false
    
    @Published var isMapView: Bool = false
    @Published var isMapViewShowed: Bool = false
    
    @Published var isAbout: Bool = false
    @Published var isAboutShowed: Bool = false
    
    @Published var isCoinStore: Bool = false
    @Published var isCoinStoreShowed: Bool = false
    
    @Published var isBottleStore: Bool = false
    @Published var isBottleStoreShowed: Bool = false
    
    @Published var isMissions: Bool = false
    @Published var isMissionsShowed: Bool = false
}

// MARK: - USO DE AppData: ObservableObject

/// Para visualizar los datos en previews:         .environmentObject(AppData())
